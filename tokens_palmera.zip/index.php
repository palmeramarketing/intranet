<?php
	header('Location: public/');