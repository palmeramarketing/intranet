<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//
// Home Route
//
Route::get('/home', 'ProductsController@indexHome')->name('home'); //Debe protegerse
//
// Login Route
//
Route::get('/', function () {
	$_session_c = session()->get('lang');
	if(isset($_session_c))
	{

	}
	else
	{
		$_lang_put = App::getLocale(); 
		session()->put('lang', 'es');
	}
	return view('auth.login');
})->name('login');
//
// Administrator Route
//
Route::get('/adminsitrator', function ()
{
	return view('administrator.administrator');
})->name('administrator'); //Debe protegerse
//
// Bank Routes
//
Route::get('/bank', 'DepartmentController@index')->name('bank'); //Debe protegerse
Route::resource('bankUpdate', 'BankController');
Route::post('BankAndDep/{id}', 'DepartmentController@update')->name('BankAndDepUpdate');
//
// Purchase Routes
//
Route::post('purchaseRequest', 'PurchaseController@purchaseRequest')->name('purchaseRequest');
Route::post('purchaseAccepted', 'PurchaseController@purchaseAccepted')->name('purchaseAccepted');
Route::post('purchaseRejected', 'PurchaseController@purchaseRejected')->name('purchaseRejected');
//
// Products Routes
//
Route::get('/products', 'ProductsController@index')->name('products'); //Debe protegerse
Route::resource('product', 'ProductsController');
//
// User Routes
//
Route::resource('user', 'UserController'); //Debe protegerse
Route::get('password', function ()
{
	return view('users.changePassword');
})->name('changePassword');
Route::post('CP/{id}', 'UserController@password')->name('CP');
//
// Notifications MaskAsRead Routes
//
Route::get('maskAsRead', function ()
{
	$user = Auth::user();
	$user->unreadNotifications->markAsRead();
	return \Redirect::back();
})->name('maskAsRead');
//
// Notifications Delete Routes
//
Route::get('deleteNotifications', function ()
{
	Auth::user()->notifications()->delete();
	return \Redirect::back();
})->name('deleteNotifications');
//
// Reward Routes
//
// Route::get('/reward', function () {
//	return view('reward.reward');
//})->name('reward'); //Debe protegerse
//
// Wallet Route
//
Route::get('/wallet', 'OperationsHistoryController@index')->name('wallet'); //Debe protegerse
Route::get('/reward', 'RewardHistoryController@index')->name('reward');
//
// Pay Routes
//
Route::post('pay', 'WalletController@pay')->name('pay'); //Debe protegerse
Route::post('payReward', 'WalletController@payReward')->name('payReward');
//
// Change Lang Route
//
Route::get('lang/{lang}', function ($lang)
{
	\Session::put('lang', $lang);
	return \Redirect::back();
})->middleware('web')->name('change_lang');
//
//
//
Auth::routes();
//Route::get('/home', 'HomeController@index')->name('home');