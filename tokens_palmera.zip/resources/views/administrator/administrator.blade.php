@extends('layouts.app')

@section('title')
	{{ trans('titles.administrator') }}
@endsection

@section('stylesheet')

@endsection

@section('navbar')
	@include('layouts.navbar')
@endsection

@section('content')
<div class="page-header">


</div>
@endsection

@section('script')

@endsection