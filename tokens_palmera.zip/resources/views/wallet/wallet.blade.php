@extends('layouts.app')

@section('title')
	{{ trans('global.wallet') }}
@endsection

@section('stylesheet')

@endsection

@section('navbar')
	@include('layouts.navbar')
@endsection

@section('content')
<div class="page-header">
    <div class="container text-center">
		<div class="card card col-md-5 f-p-m" style="display: inline-block">
		    <form class="form" id="form-pago" method="POST" action="{{ route('pay') }}" enctype="multipart/form-data">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="card-title text-center inline">Pagos</h3>
		        </div>
		        <div class="card-body">
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">mail</i>
		                    </span>
		                </div>
		                <input type="hidden" name="from" id="from" value="{{ Auth::user()->id }}">
		                <select name="to" id="to" class="form-control" required="on">
		                    <option selected="on">
		                    	Usuario
		                    </option>
		                    @php 
		                		use App\User;
		                		$users = User::get();
		                	@endphp
		                	@foreach($users as $user)
		                		@if( $user->id != Auth::user()->id)
			                		<option value="{{ $user->id }}">
			                			{{ $user->name." ".$user->last_name }}
			                		</option>
			                	@else
			                	@endif

		                	@endforeach
		                </select>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <img src="{{ asset('icons/tokens.svg') }}" id="coin" alt="" width="24">
		                    </span>
		                </div>
		                <input type="number" name="amount" id="amount" class="form-control" placeholder="Monto" required>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">edit</i>
		                    </span>
		                </div>
		                <textarea name="description" id="description" cols="20" rows="1" class="form-control" maxlength="60" placeholder="descripcion"></textarea>
		            </div>
		            <div class=" text-center">
		                <button type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="pay">Pagar</button>
		            </div>
		        </div>
		    </form>
		</div>
    </div>
</div>
<div class="main main-raised text-center">
	<div class="section section-basic" style="padding: 10px 0px">
  		<div class="container">
    		<div id="todos">
      			<div class="title">
        			<h2>Historial de operaciones</h2>
        			<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
				  		Consultar
					</button>
      			</div>
      			<div class="table-responsive">
	      			<table class="table" id="historial_operaciones" width="100%">
	        			<thead>
							<tr>
								<th>ORIGEN</th> <th>DESTINO</th> <th>MONTO </th> <th>ASUNTO</th> <th>FECHA</th>
							</tr>
	        			</thead>
			            <tbody>
			            	@if($operations->count())  
									@foreach($operations as $operation)
										@php 
											$user = User::where('id', $operation->to_user)->first();
										@endphp
										@if($operation->from_user == Auth::user()->id)  
											<tr>
												<td>{{ Auth::user()->name}}</td>
												<td>
													{{ User::where('id', $operation->to_user)->first()->name }}
												</td>
												<td class="text-danger">-{{ $operation->amount }}</td>
												<td>{{ $operation->description }}</td>
												<td>{{ $operation->created_at }}</td>
											</tr>
										@elseif($operation->to_user == Auth::user()->id)
											<tr>
												<td>
													{{ User::where('id', $operation->from_user)->first()->name }}
												</td>
												<td>{{ Auth::user()->name }}</td>
												<td class="text-success">+{{ $operation->amount }}</td>
												<td>{{ $operation->description }}</td>
												<td>{{ $operation->created_at }}</td>
											</tr>
										@else

										@endif
									@endforeach 
								@else
									<tr>
										<td colspan="8"></td>
									</tr>
		             			@endif
			            </tbody>
	      			</table>
	      		</div>
    		</div>
    	</div>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog col-md-1 mr-auto ml-auto" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Monto disponible</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  		<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<div class="modal-body">
				<div style="vertical-aling: middle">
				    <span class="float-left">
				    	<img src="{{ asset('icons/tokens.png') }}" id="coin" alt="">
				    </span>
    				<div class="" style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 15px">
    					@php
						    use App\Wallet;
						    $wallet = Wallet::where('id_user', Auth::user()->id)->value('amount');
						    echo $wallet;
						@endphp
    				</div>
    			</div>
			</div>
			<div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
			</div>
		</div>
	</div>
</div>

@endsection

@section('script')

@endsection