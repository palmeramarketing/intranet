@extends('layouts.app')

@section('title')
	{{ trans('global.bank') }}
@endsection

@section('stylesheet')
@endsection

@section('navbar')
    @include('layouts.navbar')
@endsection

@php
    use App\Bank;
    use App\Wallet;
    use App\Department;
    use App\User;
    $users = User::get();
    $banks = Bank::get();
    $wallets = Wallet::get();
    $general_amount = 0;
    // $departments = Department::get();
@endphp

@section('content')
<style>
    body
    {
        background-color: #7FB2A5;
    }       
</style>
<div class="page-header">        
    <div class="container">
        <div class="card card col-md-5 mr-auto ml-auto" style="width: 320px; height: 145px; margin-top: 10px">
            <h3 class="text-center">MONTO ACTUAL</h3>
            <br>
            <div style="vertical-aling: middle">
                <span>
                	<img src="{{ asset('icons/tokens.svg') }}" id="coin" alt="" width="30">
                </span>
                <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 0px; clear: both;">
                    <span style="float: right;" >
                        @foreach($banks as $bank)
                            @if ($bank->name == 'Presidencia')
                                {{ $bank->amount }}
                            @else
                            @endif
                        @endforeach
                    </span>
                </div>
            </div>
        </div>
        <div class="card card col-md-5 mr-auto ml-auto" style="width: 320px; height: 145px; margin-top: 30px;">
            <h3 class="text-center">EN CIRCULACIÓN</h3>
            <br>
            <div style="vertical-aling: middle">           
                <span style="">
                    <img src="{{ asset('icons/tokens.svg') }}" id="coin" alt="" width="30">
                </span>
                <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 15px">
                    <span style="float: right;">
                        @foreach($wallets as $wallet)
                            @php
                            $general_amount += $wallet->amount;
                            @endphp 
                        @endforeach
                        {{ $general_amount."" }}
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>


    <div class="text-center py-5" style="padding: 0px;">
        @if($departments->count())  
            @foreach($departments as $department)
                @foreach($banks as $bank)
                    @if($bank->name == $department->name)
                        <div class="card-container manual-flip" style="width: 275px; display: inline-block; margin: 20px; height: 350px;">
                            <div class="card" style="width: 275px; display: inline-block; margin: 10px">
                                <div class="front" style="height: 350px;">
                                    {{-- <div class="card-img-top" style="width: 275px; height: 232px; background-image: url('{{ asset('uploads/'.$product->img) }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
                                    </div> --}}
                                    {{-- <h4 class="card-title h4">{{ $product->name }}</h4> --}}
                                    
                                    <div class="card-body">
                                        <h4 class="card-text h3">{{ $department->name }}</h4>
                                        <p class="card-text" style="vertical-align: middle;">
                                            <img src="{{ asset('icons/tokens.svg') }}" width="21px" style="margin: -10px 5px 0px 0px;">
                                            <span class="h4">{{ $bank->amount }}</span>
                                        </p>
                                    </div>
                                    <div class="card-footer" style="position: absolute; bottom: 0px; left: 20%;">
                                        <button class="btn btn-primary mr-auto ml-auto" onclick="rotateCard(this)">
                                            {{ trans('global.more') }}
                                        </button>
                                    </div>
                                </div>
                                {{-- 
                                    Ajustar el diseño
                                 --}}
                                <div class="back" style="height: 350px;">
                                    <div class="card-body" style="vertical-align: middle;">
                                        <button type="button" class="close" onclick="rotateCard(this)">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <h4 class="card-text h3">{{ $department->name }}</h4>
                                        
                                        <p class="card-text" style="vertical-align: middle;">
                                            <img src="{{ asset('icons/tokens.svg') }}" width="21px" style="margin: -10px 5px 0px 0px;" id="coin">
                                            <span class="h3">{{ $bank->amount }}</span>
                                        </p>
                                        @php
                                        	$idBank = $bank->id;
                                        @endphp

                                        <form action="{{ route('BankAndDepUpdate', $idBank) }}" class="form" role="form" method="POST">

                                        	<div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <img src="{{ asset('icons/tokens.svg') }}" id="" alt="" width="24">
                                                    </span>
                                                </div>
                                                <input type="tetx" name="name" class="form-control" value="{{ $bank->name }}">
                                            </div>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                </div>
                                                <select class="form-control" name="admin" >
                                                    <option disabled>
                                                        Supervisor
                                                    </option>
                                                    @foreach($users as $user)
                                                        @if( $user->type != 1)
                                                            @if($user->id == $bank->id_admin)
                                                                <option selected value="{{ $user->id }}">
                                                                    {{ $user->name." ".$user->last_name }}
                                                                </option>
                                                            @else
                                                                <option value="{{ $user->id }}">
                                                                    {{ $user->name." ".$user->last_name }}
                                                                </option>
                                                            @endif
                                                            
                                                        @else
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <img src="{{ asset('icons/tokens.svg') }}" id="" alt="" width="24">
                                                    </span>
                                                </div>
                                                <input type="number" name="amount" class="form-control" value="{{ $bank->amount }}">
                                            </div>
                                            <div class=" text-center" style="position: absolute; bottom: 10px; left: 25%;">
                                                <input type="submit" class="btn btn-default mr-auto ml-auto" name="actualizar" value="actualizar"></input>
                                            </div>
                                            
                                        </form>
                                    </div>
                                    <div class="card-footer" style="position: fixed; bottom: 10px;">
                                        <form action="{{ route('purchaseRequest') }}" method="post" accept-charset="utf-8">
                                            <input type="hidden" name="product_id" value="{{ $department->id }}">
                                            <input type="hidden" name="product_name" value="{{ $department->name }}">
                                            <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                                            <input type="hidden" name="admin" value="{{ $department->id_admin }}">
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @else

                    @endif
                @endforeach
                
            @endforeach 
        @else
        @endif
    </div>
    {{ $departments->links() }}


@endsection

@section('script')

@endsection