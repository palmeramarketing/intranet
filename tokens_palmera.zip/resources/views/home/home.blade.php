@extends('layouts.app')
	@section('title')
		{{ trans('global.home') }}
	@endsection

	@section('stylesheet')
	@endsection
	
	@section('navbar')
    	@include('layouts.navbar')
	@endsection

	@php
	    use App\Wallet;
	    $wallet = Wallet::where('id_user', Auth::user()->id)->value('amount');
	@endphp

	@section('stylesheet')
		
	@endsection
	@section('content')
		<style>
		    body
            {
                background: rgba(165,105,189,1);
            }
		</style>  
		   
	    	@include('layouts.slider')
	    
		    <div class="text-center py-5" style="padding: 0px;">
				@if($products->count())  
					@foreach($products as $product)
						<div class="card-container manual-flip" style="width: 275px; display: inline-block; margin: 20px;">
							<div class="card" style="width: 275px; display: inline-block; margin: 10px">
								<div class="front">
									<div class="card-img-top" style="width: 275px; height: 232px; background-image: url('{{ asset('uploads/'.$product->img) }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
									</div>
									{{-- <h4 class="card-title h4">{{ $product->name }}</h4> --}}
									
									<div class="card-body">
										<h4 class="card-text h4">{{ $product->name }}</h4>
										<p class="card-text" style="vertical-align: middle;">
						                    <img src="{{ asset('icons/tokens.svg') }}" width="21px" style="margin: -10px 5px 0px 0px;">
						                    <span class="h4">{{ $product->price }}</span>
									    </p>
									</div>
									<div class="card-footer" style="position: absolute; bottom: 0px; left: 20%;">
									 	<button class="btn btn-primary mr-auto ml-auto" onclick="rotateCard(this)">
										 	{{ trans('global.more') }}
										</button>
									</div>
								</div>
								{{-- 
									Ajustar el diseño
								 --}}
								<div class="back">
									<div class="card-body" style="vertical-align: middle;">
										<button type="button" class="close" onclick="rotateCard(this)">
					      					<span aria-hidden="true">&times;</span>
					    				</button>
										<h4 class="card-text h3">{{ $product->name }}</h4>
										
										<p class="card-text" style="vertical-align: middle;">
						                    <img src="{{ asset('icons/tokens.svg') }}" width="21px" style="margin: -10px 5px 0px 0px;" id="coin">
						                    <span class="h3">{{ $product->price }}</span>
									    </p>
										<p class="card-text py-5">
											{{ $product->description }}
										</p>
									</div>
									<div class="card-footer" style="position: absolute; bottom: 0px;;">
										<form action="{{ route('purchaseRequest') }}" method="post" accept-charset="utf-8">
									    	<input type="hidden" name="product_id" value="{{ $product->id }}">
									    	<input type="hidden" name="product_name" value="{{ $product->name }}">
						  					<input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
						  					<input type="hidden" name="admin" value="{{ $product->admin }}">
						  					@if($product->price > $wallet)
												<button type="submit" class="btn btn-primary ml-auto mr-auto" name="purchase" value="{{ trans('global.purchase') }}" disabled>{{ trans('global.purchase') }}</button>
											@else
												<button type="submit" class="btn btn-primary ml-auto mr-auto" name="purchase" value="{{ trans('global.purchase') }}">{{ trans('global.purchase') }}</button>
											@endif	
									    </form>
									</div>
								</div>
							</div>
						</div>
					@endforeach 
				@else
		 		@endif
		    </div>
		    <div class="py-3">
		    	{{ $products->links() }}
		    </div>
	@endsection
@section('script')
@endsection