@php
    use App\Wallet;
    // use Session;
    use App\Product;
    use App\Bank;
    $bank = Bank::where('id', 1)->first();
    $wallet = Wallet::where('id_user', Auth::user()->id)->value('amount');
@endphp
<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="75" id="sectionsNav">
    <div class="container">
        <div class="navbar-translate">
            <a class="navbar-brand" href="{{ route('home') }}">
                TOKENS PALM ERA
            </a>
            
            <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" aria-disabled="true" >
                        <span class="" style="vertical-align: middle;">
                            <img src="{{ asset('icons/tokens.png') }}" id="coin" alt="" style="width: 19px; height: 19px; margin: -4px 6px 0px 0px;">
                            <span class="h5 font-weight-light" style="font-size: 14px;">
                                {{ $wallet }}
                            </span>
                        </span>
                    </a>
                </li>
            @if(Auth::user()->type != 1)
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('user.index') }}">
                            <i class="material-icons">
                                person_add
                            </i>
                            {{ trans('global.users') }}
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('products') }}">
                            <i class="material-icons">
                                add_shopping_cart
                            </i>
                            {{ trans('global.products') }}
                        </a>
                    </li>
                @endif
                <li class="dropdown nav-item">
                    <a href="#" class="nav-link" data-toggle="dropdown">
                        <i class="material-icons">
                            notifications
                        </i>
                        <span>
                            @if(count(Auth::user()->unreadNotifications) <= 0)
                                <sup style="display: none">{{count(Auth::user()->unreadNotifications)}}</sup>
                            @elseif(count(Auth::user()->unreadNotifications) > 0 && count(Auth::user()->unreadNotifications) <=  9)
                            <div class="bg-danger text-center" style="width: 14px; height: 14px; border-radius: 100%; display:inline-block; margin-left: -10px; padding-top: 3.5px;">
                                <sup style="font-size: 9px;color: #fff; vertical-align: middle; top: -7px;">{{count(Auth::user()->unreadNotifications)}}</sup>
                            </div>
                            @elseif(count(Auth::user()->unreadNotifications) > 9)
                            <div class="bg-danger text-center" style="width: 14px; height: 14px; border-radius: 100%; display:inline-block; margin-left: -10px; padding-top: 3.5px;">
                                <sup style="font-size: 9px;color: #fff; vertical-align: middle; top: -7px;">+9</sup>
                            </div>
                            @endif
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-with-icons force-scroll contenedor text-center" onclick="return getNotification()" style="min-width: 300px; max-height: 600px; margin-top: 0px;">
                        <a href="{{ route('maskAsRead') }}" class="dropdown-item text-center" style="margin: 0px; padding: 12px; display: inline-block; width: 112px;">
                            <i class="material-icons text-default">
                                visibility
                            </i>
                            {{-- {{ trans('global.markAllAsRead') }} --}}
                        </a>
                        <a href="{{ route('deleteNotifications') }}" class="dropdown-item text-center" style="margin: 0px; padding: 12px; display: inline-block; width: 112px;">
                            <i class="material-icons text-danger">
                                delete_forever
                            </i>
                            {{-- {{ trans('global.deleteAll') }} --}}
                        </a>
                        @php
                            use App\User;
                            $users = User::get();
                            $walletsC = Wallet::get();
                            $productsC = Product::get()
                        @endphp
                        @foreach (Auth::user()->notifications as $notification)
                            @if($notification->data['type'] == "product_added")
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="Nuevo premio" style="margin: 0px;">
                                    <i class="material-icons">
                                        add_shopping_cart
                                    </i>
                                    <span>
                                        {{ $notification->data['product']}}
                                    </span>
                                </a>
                            @elseif($notification->data['type'] == "request")
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="Quiere adquirir {{ $notification->data['product_name'] }}" style="margin: 0px;">
                                    <i class="material-icons">
                                        style
                                    </i>
                                    @foreach($users as $user)
                                        @if($user->id == $notification->data['user'])
                                            {{ $user->name }}
                                        @else
                                        @endif
                                    @endforeach  
                                        <form action="{{ route('purchaseAccepted') }}" method="post" accept-charset="utf-8" class="form-inline" style="position: absolute; right: 26.5px; bottom: 12px;">
                                            <input type="hidden" name="notification" value="{{ $notification->id }}">
                                            <input type="hidden" name="user" value="{{ $notification->data['user'] }}">
                                            <input type="hidden" name="product" value="{{ $notification->data['product_id'] }}">
                                            <input type="hidden" name="admin" value="{{ $notification->data['admin'] }}">
                                            @php
                                                $product = Product::where('id', $notification->data['product_id'])->first();
                                            @endphp
                                            <input type="hidden" name="price" value="{{ $product->price }}">
                                            <input type="hidden" name="wallet" value="{{ $wallet }}">
                                            <input type="hidden" name="bank" value="{{ $bank->amount }}">
                                            <input type="hidden" name="" value="">
                                            @foreach($walletsC as $walletC)
                                                @if($walletC->id_user ==  $notification->data['user'])
                                                    @foreach($productsC as $productC)
                                                        @if($productC->id == $notification->data['product_id'])
                                                            @if($walletC->amount >= $productC->price)
                                                                <button type="submit" class="btn btn-info btn-sm" style="margin: 0 2.5px 0 0; padding: 0; width: 25px; height: 25px;" style="vertical-align: middle;">
                                                                    <i class="material-icons" style="margin: 0;">
                                                                        done
                                                                    </i>
                                                                </button>
                                                            @else
                                                                <button type="submit" class="btn btn-default btn-sm" disabled style="margin: 0 2.5px 0 0; padding: 0; width: 25px; height: 25px;" style="vertical-align: middle;">
                                                                    <i class="material-icons" style="margin: 0;">
                                                                        done
                                                                    </i>
                                                                </button>

                                                            @endif
                                                        @else

                                                        @endif
                                                    @endforeach
                                                @else

                                                @endif
                                            @endforeach
                                            
                                        </form>
                                    <i>
                                        <form action="{{ route('purchaseRejected') }}" method="post" accept-charset="utf-8" class="form-inline" style="position: absolute; right: 0; bottom: 12px;">
                                            <input type="hidden" name="user" value="{{ $notification->data['user'] }}">
                                            <input type="hidden" name="notification"  value="{{ $notification->id }}">        
                                            <button type="submit" class="btn btn-danger btn-sm" style="margin: 0 0 0 2.5px; padding: 0; width: 25px; height: 25px;">
                                                <i class="material-icons" style="margin: 0;">
                                                    clear
                                                </i>
                                            </button>
                                        </form>
                                    </i> 
                                </a>
                            @elseif($notification->data['type'] == "rejected")
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="" style="margin: 0px;">
                                    <i class="material-icons">
                                        clear
                                    </i>
                                    <span>
                                        Solicitud rechazada
                                    </span>
                                </a>
                            @elseif($notification->data['type'] == "accepted")
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="" style="margin: 0px">
                                    <i class="material-icons">
                                        sentiment_satisfied_alt
                                    </i>
                                    <span>
                                        Compra exitosa
                                    </span>
                                </a>
                            @else
                            @endif
                        @endforeach
                    </div>
                </li>
                <li class="nav-item">
                    @php
                        $_lang = session()->get('lang');
                    @endphp
                    @if($_lang == 'en')
                        <a href="{{ route('change_lang', ['lang' => 'es']) }}" class="nav-link">
                            <img src="{{ asset('icons/en.svg') }}" width="30px" style="">
                        </a>
                    @elseif($_lang == 'es')
                        <a href="{{ route('change_lang', ['lang' => 'en']) }}" class="nav-link">
                            <img src="{{ asset('icons/es.svg') }}" width="30px" style="">
                        </a>
                    @else

                    @endif
                </li>
                {{-- <li class="dropdown nav-item">
                    <a href="#" class="nav-link" data-toggle="dropdown">
                        <i class="material-icons">
                            translate
                        </i>
                    </a>
                    <div class="dropdown-menu dropdown text-center" style="min-width: 20px; max-width: 80px;">
                        <a href="{{ route('change_lang', ['lang' => 'en']) }}" style="margin: auto; max-width: 30px;" class="">
                            <img src="{{ asset('icons/en.svg') }}" width="30px" style="">
                        </a>
                        <a href="{{ route('change_lang', ['lang' => 'es']) }}" style="margin: auto; max-width: 30px;" class="">
                            <img src="{{ asset('icons/es.svg') }}" width="30px" style="">
                        </a>
                    </div>
                </li> --}}
                <li class="dropdown nav-item">
                    <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                        <i class="material-icons">
                            account_circle
                        </i>
                        {{ Auth::user()->name }} 
                    </a>                    
                    <div class="dropdown-menu dropdown-with-icons">
                        {{--
                        <a href="{{ route('wallet') }}" class="dropdown-item">
                            <i class="material-icons">credit_card</i>Billetera
                        </a>
                        --}}
                        @if(Auth::user()->type == 3)
                            <a href="{{ route('bank') }}" class="dropdown-item">
                                <i class="material-icons">
                                    account_balance
                                </i>
                                {{ trans('global.bank') }}
                            </a>
                        @endif
                        @if(Auth::user()->type != 1)
                            <a href="{{ route('reward') }}" class="dropdown-item">
                                <i class="material-icons">
                                    redeem
                                </i>
                                {{ trans('global.reward') }}
                            </a>
                        @endif
                        {{-- <a href="{{ route('administrator') }}" class="dropdown-item">
                            <i class="material-icons">supervised_user_circle</i>Administrador
                        </a> --}}
                        <a href="{{ route('changePassword') }}" class="dropdown-item">
                            <i class="material-icons">vpn_key</i>
                            {{ trans('global.password') }}
                        </a>
                        
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="material-icons">
                                input
                            </i>
                            {{ trans('global.logout') }}
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>