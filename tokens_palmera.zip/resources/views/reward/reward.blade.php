@extends('layouts.app')

@section('title')
	{{ trans('global.reward') }}
@endsection

@section('stylesheet')

@endsection

@section('navbar')
	@include('layouts.navbar')
@endsection

@php
	use App\User;
	use App\Bank;
	use App\RewardHistory;
	$users = User::get();
	$bank = Bank::where('id_admin', Auth::user()->id)->first();
@endphp

@section('content')
<style>
	body
	{
		background-color: #79E2DB;
	}
</style>

<div class="page-header" {{-- style="height: 80vh;" --}}>        
    <div class="container text-center">
        <div class="card card col-md-5 f-p-m" style="display: inline-block">
		    <form class="form" id="form-pago" method="POST" action="{{ route('payReward') }}" enctype="multipart/form-data">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="display-4 text-uppercase">{{ trans('global.payments') }}</h3>
		        </div>
		        <div class="card-body">
		            <div class="input-group">
		                <input type="hidden" name="from" id="from" value="{{ Auth::user()->id }}">
		                {{-- <input type="hidden" name="from" id="from" value="{{ Auth::user()->id }}"> --}}
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">mail</i>
		                    </span>
		                </div>
		                <select name="to" id="to" class="form-control">
		                    <option disabled selected>
								{{ trans('global.user') }}
		                    </option>
		                    @foreach($users as $user)
		                    	@if(Auth::user()->department == $user->department)
		                    		@if(Auth::user()->id == $user->id)

		                    		@else
			                    		<option value="{{ $user->id }}">
			                    			{{ $user->name." ".$user->last_name }}
			                    		</option>
			                    	@endif
		                    	@else

		                    	@endif
		                    @endforeach
		                </select>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
			                	<img src="{{ asset('icons/tokens.svg') }}" id="coin" alt="" width="24">
			                </span>
		                </div>
		                <input type="number" name="amount" id="amount" class="form-control" placeholder="{{ trans('global.amount') }}">
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">edit</i>
		                    </span>
		                </div>
		                <textarea name="description" id="description" cols="20" rows="1" class="form-control" maxlength="20" placeholder="{{ trans('global.reason') }}"></textarea>
		            </div>
		            <div class=" text-center">
		                <button type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="payReward">{{ trans('global.request') }}</button>
		            </div>
		        </div>
		    </form>
		</div>
    </div>
</div>

<div class="main main-raised text-center">
    <div class="section section-basic" style="padding: 10px 0px">
        <div class="container">
            <div id="todos">
                <div class="title text-center text-uppercase">
                    <h2>{{ trans('global.operationHistory') }}</h2>
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
					 	{{ trans('global.consult') }}
					</button>
                </div>
                <div class="table-responsive">
	                <table class="table" id="historial_operaciones" width="100%" >
	                    <thead class="text-uppercase">
	                        <tr>
                            	<th>{{ trans('global.user') }}</th> <th>{{ trans('global.amount') }}</th> <th>{{ trans('global.reason') }}</th> <th>{{ trans('global.date') }}</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    	@foreach($rewards as $reward)
	                    		@if(Auth::user()->id == $reward->from_admin)
		                    		<tr>
		                    			<td>
		                    				@foreach($users as $user)
												@if($user->id == $reward->to_user)
													{{ $user->name." ".$user->last_name }}
												@else

												@endif
		                    				@endforeach
		                    			</td>
		                    			<td>
		                    				{{ $reward->amount }}
		                    			</td>
		                    			<td>
		                    				{{ $reward->description }}
		                    			</td>
		                    			<td>
		                    				{{ $reward->created_at }}
		                    			</td>
		                    		</tr>
	                    		@else

	                    		@endif
	                    	@endforeach
	                        
	                    </tbody>
	                </table>
	            </div>
	            {{ $rewards->links() }}
            </div>
		</div>
	</div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
	  		<div class="modal-header">
	    		<h5 class="modal-title" id="exampleModalLabel">Monto actual</h5>
			    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			    	<span aria-hidden="true">&times;</span>
			    </button>
			</div>

  			<div class="modal-body">
  				<div style="vertical-aling: middle">
                    <span class="float-left">
                    	<img src="{{ asset('icons/tokens.png') }}" id="coin" alt="">
                    </span>
                    <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 15px">
                      	{{ $bank->amount }}
                    </div>
                </div>
			</div>
			
			<div class="modal-footer">
			    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	  		</div>
		</div>
	</div>
</div>
@endsection

@section('script')

@endsection