@extends('layouts.app')

@section('title')
    {{ trans('global.login') }}
@endsection

@section('stylesheet')

@endsection

@section('navbar')
<style>
    .card-login .form {
        min-height: 350px !important;
    }
    .page-header
    {
        background: rgba(255,129,137,1);
    }
</style>
@endsection

@section('content')
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 ml-auto mr-auto card-login">
                    <div class="card card-login">
                        <form class="form" id="form-inicio-sesion" method="POST" action="{{ route('login') }}">
                            <div class="card-header card-header-primary text-center">
                                <h4 class="display-4 text-uppercase">{{ trans('global.login') }}</h4>
                                @php
                                    $_lang = session()->get('lang');;
                                @endphp
                                @if($_lang == 'en')
                                    <a href="{{ route('change_lang', ['lang' => 'es']) }}" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="{{ asset('icons/en.svg') }}" alt="" class="material-icons" width="35px">
                                    </a>
                                @elseif($_lang == 'es')
                                    <a href="{{ route('change_lang', ['lang' => 'en']) }}" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="{{ asset('icons/es.svg') }}" alt="" class="material-icons" width="35px">
                                    </a>
                                @else

                                @endif
                                <span class="text-white text-uppercase" style="font-size: 12px;">
                                    {{ trans('global.o') }}
                                </span>
                                <a href="{{ route('register') }}" class="text-white text-uppercase mr-auto ml-auto" style="font-size: 12px;">
                                    {{ trans('global.register') }}
                                </a>
                            </div>
                            <p class="description text-center">TOKENS PALM ERA</p>
                                <div class="card-body">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">mail</i>
                                            </span>
                                        </div>
                                        <input type="email" name="email" id="email" class="form-control" placeholder="{{ trans('global.email') }}" autocomplete="on"  required="on">
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">vpn_key</i>
                                            </span>
                                        </div>
                                        <input type="password" name="password" id="password" class="form-control" placeholder="{{ trans('global.password') }}" autocomplete="on"  required="on">
                                    </div>
                                </div>
                                <div class=" text-center">
                                    <button type="submit" class="btn btn-primary btn-link btn-lg">{{ trans('global.login') }}</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')

@endsection
