@extends('layouts.app')

@section('title')
    {{ trans('global.register') }}
@endsection

@section('stylesheet')
@endsection

@section('navbar')
<style>
    .card-login .form {
        min-height: 350px !important;
    }
    .page-header
    {
        background: rgba(255,129,137,1);
    }
</style>
@endsection

@section('content')
    <div class="page-header">
        <div class="container">
            <div class="">
                <div class="col-lg-4 col-md-6 ml-auto mr-auto">
                    <div class="card">
                        <form class="form" id="form-pago" method="POST" action="{{ route('user.store') }}">
                            <div class="card-header card-header-primary text-center h">
                                <h4 class="display-4 text-uppercase">{{ trans('global.register') }}</h4>
                                @php
                                    $_lang = session()->get('lang');;
                                @endphp
                                @if($_lang == 'en')
                                    <a href="{{ route('change_lang', ['lang' => 'es']) }}" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="{{ asset('icons/en.svg') }}" alt="" class="material-icons" width="35px">
                                    </a>
                                @elseif($_lang == 'es')
                                    <a href="{{ route('change_lang', ['lang' => 'en']) }}" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="{{ asset('icons/es.svg') }}" alt="" class="material-icons" width="35px">
                                    </a>
                                @else

                                @endif
                                <span class="text-white text-uppercase" style="font-size: 12px;">
                                    {{ trans('global.o') }}
                                </span>
                                <a href="{{ route('login') }}" class="text-white text-uppercase" style="font-size: 12px;">
                                    {{ trans('global.login') }}
                                </a>
                                
                            </div>
                            <div class="card-body">            
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">person</i>
                                        </span>
                                    </div>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="{{ trans('global.name') }}" style="" required="on">
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">person</i>
                                        </span>
                                    </div>
                                    <input type="text" name="last_name" id="last_name" class="form-control" placeholder="{{ trans('global.lastName') }}" style="margin-left: 0px;" required="on">
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">mail</i>
                                        </span>
                                    </div>
                                    <input type="text" name="email" id="email" class="form-control" placeholder="{{ trans('global.email') }}" value="" required="on" data-toggle="tooltip" data-html="true" data-placement="right" title="{{ trans('global.emailRegister') }}">
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">group</i>
                                        </span>
                                    </div>
                                    <select class="form-control" name="type">
                                        <option value="1" selected disabled>
                                            {{ trans('global.user') }}/{{ trans('global.admin') }}
                                        </option>

                                        <option value="1" id="user"> 
                                            {{ trans('global.user') }}
                                        </option>

                                        <option value="2" id="admin">
                                            {{ trans('global.admin') }}
                                        </option>
                                        
                                    </select>
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">group_work</i>
                                        </span>
                                    </div>
                                    <select class="form-control" name="department">
                                        <option selected disabled>
                                            {{ trans('global.department') }}
                                        </option>
                                        @php 
                                            use App\Department;
                                            $departments = Department::get();
                                        @endphp
                                        @foreach($departments as $department)
                                            <option value="{{ $department->id }}">
                                                {{ $department->name }}
                                            </option>

                                        @endforeach
                                        
                                    </select>
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">vpn_key</i>
                                        </span>
                                    </div>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="{{ trans('global.password') }}" style="" required="on">
                                    <button type="button" class="btn btn-sm btn-link" onclick=" cambiar();"><i class="material-icons">remove_red_eye</i></button>
                                </div>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">vpn_key</i>
                                        </span>
                                    </div>
                                    <input type="password" name="passwordConfirm" id="passwordConfirm" class="form-control" placeholder="{{ trans('global.passwordC') }}" style="" required="on">
                                    <button type="button" class="btn btn-sm btn-link" onclick=" cambiar2();"><i class="material-icons">remove_red_eye</i></button>
                                </div>
                                <div class=" text-center">
                                    <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" id="changePasswordButton" name="registrar" value="{{ trans('global.register') }}" disabled></input>
                                </div>
                            </div>
                        </form>  
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
<script type="application/javascript">
    function cambiar()
    {
        var password = document.getElementById('password');
        if (password.type == 'password')
        {
            password.type = 'text';
        }
        else
        {
            password.type = 'password';
        }
    }
    function cambiar2()
    {
        var passwordConfirm = document.getElementById('passwordConfirm');
        if (passwordConfirm.type == 'password')
        {
            passwordConfirm.type = 'text';
        }
        else
        {
            passwordConfirm.type = 'password';
        }
    }
    function confirmPassword()
    {
        var passwordO = document.getElementById('password');
        var passwordC = document.getElementById('passwordConfirm');
        var passwordConfirm = document.getElementById('changePasswordButton');

        if (passwordO.value == passwordC.value && passwordO.value.length >= 8)
        {
            passwordConfirm.removeAttribute('disabled');
        }
        else
        {
            passwordConfirm.setAttribute('disabled', 'on');
        }
    }
    setInterval("confirmPassword()", 5);
</script>

@endsection

