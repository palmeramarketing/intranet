@extends('layouts.app')

@section('title')
	{{ trans('global.products') }}
@endsection

@section('stylesheet')

@endsection

@section('navbar')
	@include('layouts.navbar')
@endsection

@section('content')
	<style>
		body
		{
			background-color: #79E2DB;
		}		
	</style>

<div class="page-header">
    <div class="container text-center">
        <div class="card card col-md-5 f-p-m" style="display: inline-block" >
    		<form class="form" id="form-pago" method="POST" action="{{ route('product.store') }}" enctype="multipart/form-data">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="display-4 text-uppercase">{{ trans('global.registerUser') }}</h3>
		        </div>

        		<div class="card-body">
	            	<div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">add_shopping_cart</i>
		                    </span>
		                </div>
	                	<input type="text" name="name" id="name" class="form-control" placeholder="{{ trans('global.products') }}" style="" required="on">
	            	</div>

	            	<div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">edit</i>
		                    </span>
		                </div>
		                <textarea name="description" id="description" cols="20" rows="2" class="form-control" maxlength="" placeholder="{{ trans('global.description') }}"></textarea>
		            </div>
		            <div class="input-group">
		            	<div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">person</i>
		                    </span>
		                </div>
		                <select class="form-control" name="admin" >
		                	<option selected disabled>
		                		{{ trans('global.responsable') }}
		                	</option>
		                	@php 
		                		use App\User;
		                		$users = User::get();
		                	@endphp
		                	@foreach($users as $user)
		                		@if( $user->type != 1)
			                		<option value="{{ $user->id }}">
			                			{{ $user->name." ".$user->last_name }}
			                		</option>
			                	@else
			                	@endif
		                	@endforeach
		                </select>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
			                	<img src="{{ asset('icons/tokens.svg') }}" id="" alt="" width="24">
			                </span>
		                </div>
		                <input type="number" name="price" id="price" class="form-control" placeholder="{{ trans('global.price') }}" style="margin-left: 0px;" required="on">
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">insert_photo</i>
		                    </span>
		                </div>
		                <span class="file-upload">
		                	<input type="file" id="file-upload" onchange="cambiar()" accept="image/*" name="img" id="img" class="form-control" placeholder="Precio" style="display:none;" required>
		                </span>
		                <input type="text" name="" id="info" class="form-control" disabled style="background-color: #fff;">
		                <label for="file-upload" class="subir btn btn-primary btn-fab btn-round">
		               		<i class="material-icons">attach_file</i>							
		                </label>
		            </div>
		            <div class=" text-center">
		                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="registrar" value="{{ trans('global.registerUser') }}"></input>
		            </div>
		        </div>
    		</form>
		</div>
    </div>
</div>               
<div class="main main-raised">
    <div class="section section-basic" style="padding: 10px 0px">
        <div class="container">
            <div id="">
                <div class="title text-center text-uppercase">
                    <h2>{{ trans('global.products') }}</h2>
                </div>
            </div>
            <div class="table-responsive">
            <table class="table responsive-table centered text-center" id="historial_operaciones" width="100%" >
                <thead class="text-uppercase">
                    <tr>
                        <th id="lok" value="lokj">{{ trans('global.name') }}</th> <th>{{ trans('global.description') }}</th> <th>{{ trans('global.responsable') }}</th> <th>{{ trans('global.price') }}</th>  <th>{{ trans('global.edit') }}</th> <th>{{ trans('global.delete') }}</th>
                    </tr>
                </thead>
                <tbody>
                	@if($products->count())  
						@foreach($products as $product)  
							<tr>
								<td>{{$product->name}}</td>
								<td>{{$product->description}}</td>
								<td>@foreach($users as $user)
										@if($user->id == $product->admin)
											{{ $user->name." ".$user->last_name }}
										@else
										@endif
									@endforeach
									</td>
								<td>{{$product->price}}</td>
								<td>
									<button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#exampleModal-{{ $product->id }}">
								  		<span class="glyphicon glyphicon-pencil">
											<i class="material-icons">edit</i>
										</span>
									</button>
									<div class="modal fade" id="exampleModal-{{ $product->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  	<div class="modal-dialog" role="document">
									    	<div class="modal-content">
									    		<div class="modal-header">
									    			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
      													<span aria-hidden="true">&times;</span>
    												</button>
									    		</div>
									      		<div class="modal-body" style="z-index: 40;">
									        		<form class="form" id="form-pago" method="POST" action="{{ route('product.update', $product->id) }}" role="form" enctype="multipart/form-data">
										    			{{ csrf_field() }}
										    			<input name="_method" type="hidden" value="PATCH">
										    			<div class="card-header card-header-primary text-center" style="vertical-align: middle; ">
												        	<div style="width: 250px; height: 250px; background-image: url('{{ asset('uploads/'.$product->img) }}'); background-position: center; background-repeat: no-repeat; background-size: cover; border-radius: 0%; display: inline-block; vertical-align: middle; margin: 0 auto;">
												        	</div>
												        </div>
										        		<div class="card-body py-3">
											            	<div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">add_shopping_cart</i>
												                    </span>
												                </div>
											                	<input type="text" name="name" id="name" class="form-control" placeholder="Producto" style="" required="on" value="{{ $product->name }}">
											            	</div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">edit</i>
												                    </span>
												                </div>
												                <textarea name="description" id="description" cols="20" rows="2" class="form-control" maxlength="" placeholder="Descripción" value="{{ $product->description }}">{{ $product->description }}</textarea>
												            </div>
												            <div class="input-group">
												            	<div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">person</i>
												                    </span>
												                </div>
												                <select class="form-control" name="admin" >
												                	<option disabled>
												                		Supervisor
												                	</option>
												                	@foreach($users as $user)
												                		@if( $user->type != 1)
												                			@if($user->id == $product->admin)
												                				<option selected value="{{ $user->id }}">
														                			{{ $user->name." ".$user->last_name }}
														                		</option>
												                			@else
																				<option value="{{ $user->id }}">
														                			{{ $user->name." ".$user->last_name }}
														                		</option>
												                			@endif
													                		
													                	@else
													                	@endif
												                	@endforeach
												                </select>
												            </div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">euro</i>
												                    </span>
												                </div>
												                <input type="number" name="price" id="price" class="form-control" placeholder="Precio" style="margin-left: 0px;" required="on" value="{{ $product->price }}">
												            </div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                    	
												                        <i class="material-icons">insert_photo</i>
												                    </span>
												                </div>
												                <span class="file-upload">
												                	<input type="file" id="file-upload-{{ $product->id }}" onchange="cambiar_{{ $product->id }}()" accept="image/*" name="img" id="img" class="form-control" placeholder="Precio" style="display:none;">
												                </span>
												                <input type="text" name="" id="info-{{ $product->id }}" class="form-control" disabled style="background-color: #fff;" value="">
												                <label for="file-upload-{{ $product->id }}" class="subir btn btn-primary btn-fab btn-round" value="">
												               		<i class="material-icons">attach_file</i>							
												                </label>
												                <script type="application/javascript">
																	function cambiar_{{ $product->id }}(){
															    		var pdrs = document.getElementById('file-upload-{{ $product->id }}').files[0].name;
															   			document.getElementById('info-{{ $product->id }}').value = pdrs;
																	}
																</script>
												            </div>
												            <div class=" text-center">
												                <input type="submit" class="btn btn-default btn-link btn-wd btn-lg" name="actualizar" value="actualizar">
												            </div>
												        </div>
										    		</form>
									      		</div>
									    	</div>
									  	</div>
									</div>
									</td>
								<td>
									<form action="{{action('ProductsController@destroy', $product->id)}}" method="post">
										{{csrf_field()}}
										<input name="_method" type="hidden" value="DELETE">
										<button class="btn btn-danger btn-sm" type="submit">
											<span class="glyphicon glyphicon-trash">
												<i class="material-icons">delete</i>
											</span>
										</button>
									</form>
								</td>
							</tr>
						@endforeach 
						@else
							<tr>
								<td colspan="8"></td>
							</tr>
             		 @endif
                </tbody>
            </table>
        </div>
        <span>{{ $products->links() }}</span>
        </div>
    </div>
</div>
@endsection

@section('script')
	<script type="application/javascript">
		function cambiar(){
    		var pdrs = document.getElementById('file-upload').files[0].name;
   			document.getElementById('info').value = pdrs;
		}
	</script>
	<style type="text/css" media="screen">
		.modal-backdrop	{
			z-index: -3;
		}		
	</style>
@endsection