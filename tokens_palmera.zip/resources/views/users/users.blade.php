@extends('layouts.app')

@section('title')
	{{ trans('global.users') }}
@endsection

@section('stylesheet')
@endsection

@section('navbar')
	@include('layouts.navbar')
@endsection

@php
	use App\Department;
	$departments = Department::get();
@endphp

@section('content')
	<style>
		body
		{
			background-color: #00A6CE;
		}		
	</style>
	<div class="page-header" {{-- style="height: 75vh;" --}}>
    	<div class="container text-center">
        	<div class="card card col-md-5 f-p-m" style="display: inline-block" >
    			<form class="form" id="form-pago" method="POST" action="{{ route('user.store') }}">
		        	<div class="card-header card-header-primary text-center h">
		            	<h3 class="display-4 text-uppercase">{{ trans('global.registerUser') }}</h3>
		        	</div>
        			<div class="card-body">
						            
	            		<div class="input-group">
		                	<div class="input-group-prepend">
		                    	<span class="input-group-text">
		                        	<i class="material-icons">person</i>
		                    	</span>
		                	</div>
	                		<input type="text" name="name" id="name" class="form-control" placeholder="{{ trans('global.name') }}" style="" required="on">
	            		</div>
			            <div class="input-group">
			                <div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">person</i>
			                    </span>
			                </div>
			                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="{{ trans('global.lastName') }}" style="margin-left: 0px;" required="on">
			            </div>
			            <div class="input-group">
			                <div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">mail</i>
			                    </span>
			                </div>
			                <input type="text" name="email" id="email" class="form-control" placeholder="{{ trans('global.email') }}" value="" required="on" autocomplete="off" data-toggle="tooltip" data-html="true" data-placement="right" title="{{ trans('global.emailRegister') }}">
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">group</i>
			                    </span>
			                </div>
			                <select class="form-control" name="type">
			                	<option value="1" selected disabled>
			                		{{ trans('global.user') }}/{{ trans('global.admin') }}
			                	</option>

			                	<option value="1" id="user"> 
			                		Usuario
			                	</option>

			                	<option value="2" id="admin">
			                		Administrador
			                	</option>
			                	
			                </select>
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">group_work</i>
			                    </span>
			                </div>
			                <select class="form-control" name="department">
			                	<option selected disabled>
			                		{{ trans('global.department') }}
			                	</option>
			                	@foreach($departments as $department)
			                		<option value="{{ $department->id }}">
			                			{{ $department->name }}
			                		</option>

			                	@endforeach
			                	
			                </select>
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">vpn_key</i>
			                    </span>
			                </div>
			                <input type="password" name="password" id="password" class="form-control" placeholder="{{ trans('global.password') }}" value="" required="on" autocomplete="off">
			            </div>
			            <div class=" text-center">
			                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="registrar" value="{{ trans('global.registerUser') }}"></input>
			            </div>
		        	</div>
    			</form>
			</div>
    	</div>
	</div>
	<div class="main main-raised">
    	<div class="section section-basic" style="padding: 10px 0px">
        	<div class="container">
            	<div id="">
                	<div class="title text-center text-uppercase">
                    	<h2>{{ trans('global.users') }}</h2>
                	</div>
            	</div>

            	<div class="table-responsive">
	            	<table class="table table-striped text-center" width="100%">
	                	<thead class="text-uppercase">
	                    	<tr>
	                        	<th>{{ trans('global.name') }}</th> <th>{{ trans('global.lastName') }}</th> <th>{{ trans('global.email') }}</th> <th>{{ trans('global.edit') }}</th> <th>{{ trans('global.delete') }}</th>
	                    	</tr>
	                	</thead>

	                	<tbody>
	                		@if($users->count())  
								@foreach($users as $user)  
									<tr>
										<td>{{$user->name}}</td>
										<td>{{$user->last_name}}</td>
										<td>{{$user->email}}</td>
										<td>
											<button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#exampleModal-{{ $user->id }}">
										  		<span class="glyphicon glyphicon-pencil">
													<i class="material-icons">edit</i>
												</span>
											</button>
											<div class="modal fade" id="exampleModal-{{ $user->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  	<div class="modal-dialog" role="document">
											    	<div class="modal-content">
											      		<div class="modal-body">
											      			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          													<span aria-hidden="true">&times;</span>
	        												</button>
											      			
											        		<form class="form" id="form-pago" method="POST" action="{{ route('user.update', $user->id) }}" role="form">
												    			{{ csrf_field() }}
												    			<input name="_method" type="hidden" value="PATCH">
														        <div class="card-header card-header-primary text-center h">
														            <h3 class="card-title text-center inline">Editar</h3>
														        </div>

												        		<div class="card-body">
												            
													            	<div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">person</i>
														                    </span>
														                </div>
													                	<input type="text" name="name" id="name" class="form-control" placeholder="Nombre" style="" required="on" value="{{ $user->name }}">
													            	</div>

														            <div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">person</i>
														                    </span>
														                </div>
														                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Apellido" style="margin-left: 0px;" required="on" value="{{ $user->last_name }}">
														            </div>
												            
														            <div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">mail</i>
														                    </span>
														                </div>
														                <input type="email" name="email" id="email" class="form-control" placeholder="Example@palmera.marketing" required="on" value="{{ $user->email }}">
														            </div>

														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">group</i>
														                    </span>
														                </div>
														                <select class="form-control" >
														                	<option value="user" selected disabled>
														                		Usuario/Administrador
														                	</option>

														                	<option value="user" id="user"> 
														                		Usuario
														                	</option>

														                	<option value="admin" id="admin">
														                		Administrador
														                	</option>
														                	
														                </select>
														            </div>

														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">group_work</i>
														                    </span>
														                </div>
														                <select class="form-control" value="">
														                	<option value="user" selected disabled>
														                		Equipo
														                	</option>
																			@foreach($departments as $department)
																				<option value="{{ $department->id }}">
																					{{ $department->name }}
																				</option>
																			@endforeach
														                </select>
														            </div>
														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">vpn_key</i>
														                    </span>
														                </div>
														                <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña" value="" required="on" value="{{ $user->password }}">
														            </div>
														            <div class=" text-center">
														                <input type="submit" class="btn btn-default btn-link btn-wd btn-lg" name="actualizar" value="actualizar"></input>
														            </div>
														        </div>
												    		</form>
											      		</div>
											    	</div>
											  	</div>
											</div>
										</td>
										<td>
											<button type="button" class="btn btn-danger  btn-sm" data-toggle="modal" data-target="#exampleModal2-{{ $user->id }}">
											 	<span class="glyphicon glyphicon-trash">
													<i class="material-icons">delete</i>
												</span>
											</button>
											<div class="modal fade" id="exampleModal2-{{ $user->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  	<div class="modal-dialog" role="document">
											    	<div class="modal-content">
												      	<div class="modal-body">
												      		<div class="card-header card-header-primary text-center h">
										        				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										          					<span aria-hidden="true">&times;</span>
										        				</button>
												            	<h3 class="card-title text-center inline">Eliminar</h3>
												        	</div>
												      		<p>¿Realmente desea eliminar a {{ $user->name." ".$user->last_name }}?</p>
												      	</div>
											      		<div class="modal-footer text-center">
											        		<form class="form-inline text-center mr-auto ml-auto" action="{{action('UserController@destroy', $user->id)}}" method="post">
																{{ csrf_field() }}
																<input name="_method" type="hidden" value="DELETE">
																<button class="btn btn-danger btn-link btn-wd btn-lg" type="submit">
																	Eliminar
																</button>
															</form>
											      		</div>
											    	</div>
											  	</div>
											</div>
										</td>
									</tr>
								@endforeach 
							@else
								<tr>
									<td colspan="8"></td>
								</tr>
	             			@endif
	                	</tbody>
	            	</table>
            	</div>
            	{{ $users->links() }}
        	</div>
    	</div>
	</div>
@endsection

@section('script')
	<style type="text/css" media="screen">
		.modal-backdrop	{
			z-index: -3;
		}		
	</style>
@endsection