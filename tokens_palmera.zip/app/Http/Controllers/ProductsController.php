<?php

namespace App\Http\Controllers;
use Illuminate\Notifications\Notifiable;
use Illuminate\Http\Request;
use App\Product;
use Illuminate\Support\Facades\Storage;
use App\Notifications\NewProductAdded;
use App\User;

class ProductsController extends Controller
{
    public function index()
    {
        $products = Product::orderBy('id', 'DESC')->paginate(10);
        return view('products.products', compact('products'))->with('success','Producto registro satisfactoriamente');
    }
    public function indexHome()
    {
        //
        $products = Product::orderBy('id', 'DESC')->paginate(20);
        return view('home.home', compact('products'));
    }
    public function create()
    {
        //
    }
    public function store(Request $request)
    {
        $this->validate($request, ['name' => 'required', 'description' => 'required', 'price' => 'required', 'img' => 'required']);
        $img = $request->file('img');
        $img_name = $img->getClientOriginalName();
        $img->move('uploads', $img_name);
        $product = Product::create([
            'name'=>$request->input('name'),
            'description'=>$request->input('description'),
            'price'=>$request->input('price'),
            'admin'=> $request->input('admin'),
            'img'=> $img_name,
        ]);
        $users = User::all();
        foreach ($users as $user) {
            $user->notify(new NewProductAdded($product));
        }
        return \Redirect::back()->with('success','Producto añadido satisfactoriamente');
    }
    public function show($id)
    {
        //
    }
    public function edit($id)
    {
        //
    }
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, ['name' => 'required', 'description' => 'required', 'price' => 'required',]);
        $imgC = $request->input('img');
        $img = $request->file('img');
        if (is_null($img))
        {
             Product::find($id)->update([
                'name' => $request->input('name'),
                'description' => $request->input('description'),
                'admin'=> $request->input('admin'),
                'price' => $request->input('price'),
    
            ]);   
        }
        else
        {
            $img = $request->file('img');
            $img_name = $img->getClientOriginalName();
            $img->move('uploads', $img_name);
            Product::find($id)->update([
                'name' => $request->input('name'),
                'description' => $request->input('description'),
                'admin'=> $request->input('admin'),
                'price' => $request->input('price'),
                'img' => $img_name,
            ]);
        }   
               
        
        return \Redirect::route('products')->with('success','Producto actualizado satisfactoriamente.');
    }
    public function destroy($id)
    {
        Product::find($id)->delete();
        return \Redirect::back()->with('danger','Producto eliminado satisfactoriamente');
    }
}
