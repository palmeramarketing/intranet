<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Wallet;

class UserController extends Controller
{
    public function index()
    {
        //
        $users = User::orderBy('name', 'ASC')->paginate(15);
        return view('users.users', compact('users'));
    }
    public function create()
    {
        //
    }
    public function registerRequest (Request $request) {
        //
    }
    public function registerAccepted () {
        //
    }
    public function registerRejected () {
        //
    }
    public function store(Request $request)
    {
        //
        $this->validate($request, ['name' => 'required', 'last_name' => 'required', 'email' => 'required', 'type' => 'required', 'department' => 'required', 'password' => 'required']);
        $password = $request->input('password');
        $hashed = Hash::make($password);

        User::create([
            'name' => $request->input('name'),
            'last_name' => $request->input('last_name'),
            'email' => $request->input('email')."@palmera.marketing",
            'type' => intval($request->input('type')),
            'department' => $request->input('department'),
            'password' => $hashed,
        ]);
        $id = User::where('email', $request->input('email')."@palmera.marketing")->value('id');
        Wallet::create([
            'id_user' => $id,
            'state' => 1,
            'amount' => 0,
        ]);
        return \Redirect::back()->with('success','Usuario creado satisfactoriamente');
    }
    public function show($id)
    {
        //
        
    }
    public function edit($id)
    {
        //
        $user = User::find($id);
        return view('users.edit', compact('user'));
    }
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, ['name' => 'required', 'last_name' => 'required', 'email' => 'required', 'password' => 'required']);
        $password = $request->input('password');
        $hashed = Hash::make($password);
        User::find($id)->update([
            'name' => $request->input('name'),
            'last_name' => $request->input('last_name'),
            'email' => $request->input('email'),
            'password' => $hashed,
        ]);
        return \Redirect::route('user.index')->with('success','Usuario actualizado satisfactoriamente.');
    }
    public function password(Request $request, $id)
    {
        //
        $this->validate($request, ['password' => 'required', 'passwordConfirm' => 'required']);
        if ($request->input('password') == $request->input('passwordConfirm'))
        {
            $password = $request->input('password');
            $hashed = Hash::make($password);
            User::find($id)->update([
                'password' => $hashed,
            ]);
            return \Redirect::route('changePassword')->with('success','Contraseña actualizada satisfactoriamente.');
        }
        

    }
    public function destroy($id)
    {
        //
        Wallet::where('id_user', $id)->delete();
        User::find($id)->delete();
        return \Redirect::back()->with('danger','Usuario eliminado satisfactoriamente');
    }
}
