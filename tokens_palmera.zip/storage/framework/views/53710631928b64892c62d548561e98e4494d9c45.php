<div class="card" style="width: 20rem; display: inline-block; margin: 20px">
	<img class="card-img-top" src="https://images.unsplash.com/photo-1517303650219-83c8b1788c4c?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=bd4c162d27ea317ff8c67255e955e3c8&auto=format&fit=crop&w=2691&q=80" alt="">
	<div class="card-body">
		<h4 class="card-title"><?php echo $__env->yieldContent('name'); ?></h4>
	    <p class="card-text">Resumen del producto</p>
	</div>
	 <div class="card-footer">
	 	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
		 	Información
		</button>
	 	
	</div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
  			<div class="modal-header">
  				<h4 class="modal-title">Nombre del producto</h4>
    			<button type="button" class="close" data-dismiss="modal" aria-label="Close">

      				<span aria-hidden="true">&times;</span>
    			</button>
  			</div>
  			<div class="modal-body">
  				
				 	<div class="card-body">
				    	
				    <p class="card-text">Información completa del producto.</p>
				    <p class="card-text"><small class="text-muted">Precio</small></p>
				  </div>
				  <img class="card-img-bottom" src="https://images.unsplash.com/photo-1517303650219-83c8b1788c4c?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=bd4c162d27ea317ff8c67255e955e3c8&auto=format&fit=crop&w=2691&q=80" alt="">
				

  			</div>
  			<div class="modal-footer">
			    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			    <button type="button" class="btn btn-primary">Comprar</button>
  			</div>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/products/products_card.blade.php ENDPATH**/ ?>