<?php $__env->startSection('title'); ?>
    <?php echo e(trans('global.login')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<style>
    .card-login .form {
        min-height: 350px !important;
    }
    .page-header
    {
        background: rgba(255,129,137,1);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 ml-auto mr-auto card-login">
                    <div class="card card-login">
                        <form class="form" id="form-inicio-sesion" method="POST" action="<?php echo e(route('login')); ?>">
                            <div class="card-header card-header-primary text-center">
                                <h4 class="display-4 text-uppercase"><?php echo e(trans('global.login')); ?></h4>
                                <?php
                                    $_lang = session()->get('lang');;
                                ?>
                                <?php if($_lang == 'en'): ?>
                                    <a href="<?php echo e(route('change_lang', ['lang' => 'es'])); ?>" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="<?php echo e(asset('icons/en.svg')); ?>" alt="" class="material-icons" width="35px">
                                    </a>
                                <?php elseif($_lang == 'es'): ?>
                                    <a href="<?php echo e(route('change_lang', ['lang' => 'en'])); ?>" class="btn btn-white btn-link float-left" style="bottom: 15px;">
                                        <img src="<?php echo e(asset('icons/es.svg')); ?>" alt="" class="material-icons" width="35px">
                                    </a>
                                <?php else: ?>

                                <?php endif; ?>
                                <span class="text-white text-uppercase" style="font-size: 12px;">
                                    <?php echo e(trans('global.o')); ?>

                                </span>
                                <a href="<?php echo e(route('register')); ?>" class="text-white text-uppercase mr-auto ml-auto" style="font-size: 12px;">
                                    <?php echo e(trans('global.register')); ?>

                                </a>
                            </div>
                            <p class="description text-center">TOKENS PALM ERA</p>
                                <div class="card-body">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">mail</i>
                                            </span>
                                        </div>
                                        <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(trans('global.email')); ?>" autocomplete="on"  required="on">
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">vpn_key</i>
                                            </span>
                                        </div>
                                        <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(trans('global.password')); ?>" autocomplete="on"  required="on">
                                    </div>
                                </div>
                                <div class=" text-center">
                                    <button type="submit" class="btn btn-primary btn-link btn-lg"><?php echo e(trans('global.login')); ?></button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/auth/login.blade.php ENDPATH**/ ?>