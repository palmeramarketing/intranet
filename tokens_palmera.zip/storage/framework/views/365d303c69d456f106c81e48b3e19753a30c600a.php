<?php $__env->startSection('title'); ?>
	<?php echo e(trans('global.reward')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php
	use App\User;
	use App\Bank;
	use App\RewardHistory;
	$users = User::get();
	$bank = Bank::where('id_admin', Auth::user()->id)->first();
?>

<?php $__env->startSection('content'); ?>
<style>
	body
	{
		background-color: #79E2DB;
	}
</style>

<div class="page-header" >        
    <div class="container text-center">
        <div class="card card col-md-5 f-p-m" style="display: inline-block">
		    <form class="form" id="form-pago" method="POST" action="<?php echo e(route('payReward')); ?>" enctype="multipart/form-data">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="display-4 text-uppercase"><?php echo e(trans('global.payments')); ?></h3>
		        </div>
		        <div class="card-body">
		            <div class="input-group">
		                <input type="hidden" name="from" id="from" value="<?php echo e(Auth::user()->id); ?>">
		                
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">mail</i>
		                    </span>
		                </div>
		                <select name="to" id="to" class="form-control">
		                    <option disabled selected>
								<?php echo e(trans('global.user')); ?>

		                    </option>
		                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    	<?php if(Auth::user()->department == $user->department): ?>
		                    		<?php if(Auth::user()->id == $user->id): ?>

		                    		<?php else: ?>
			                    		<option value="<?php echo e($user->id); ?>">
			                    			<?php echo e($user->name." ".$user->last_name); ?>

			                    		</option>
			                    	<?php endif; ?>
		                    	<?php else: ?>

		                    	<?php endif; ?>
		                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </select>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
			                	<img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="coin" alt="" width="24">
			                </span>
		                </div>
		                <input type="number" name="amount" id="amount" class="form-control" placeholder="<?php echo e(trans('global.amount')); ?>">
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">edit</i>
		                    </span>
		                </div>
		                <textarea name="description" id="description" cols="20" rows="1" class="form-control" maxlength="20" placeholder="<?php echo e(trans('global.reason')); ?>"></textarea>
		            </div>
		            <div class=" text-center">
		                <button type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="payReward"><?php echo e(trans('global.request')); ?></button>
		            </div>
		        </div>
		    </form>
		</div>
    </div>
</div>

<div class="main main-raised text-center">
    <div class="section section-basic" style="padding: 10px 0px">
        <div class="container">
            <div id="todos">
                <div class="title text-center text-uppercase">
                    <h2><?php echo e(trans('global.operationHistory')); ?></h2>
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
					 	<?php echo e(trans('global.consult')); ?>

					</button>
                </div>
                <div class="table-responsive">
	                <table class="table" id="historial_operaciones" width="100%" >
	                    <thead class="text-uppercase">
	                        <tr>
                            	<th><?php echo e(trans('global.user')); ?></th> <th><?php echo e(trans('global.amount')); ?></th> <th><?php echo e(trans('global.reason')); ?></th> <th><?php echo e(trans('global.date')); ?></th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    	<?php $__currentLoopData = $rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    		<?php if(Auth::user()->id == $reward->from_admin): ?>
		                    		<tr>
		                    			<td>
		                    				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($user->id == $reward->to_user): ?>
													<?php echo e($user->name." ".$user->last_name); ?>

												<?php else: ?>

												<?php endif; ?>
		                    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    			</td>
		                    			<td>
		                    				<?php echo e($reward->amount); ?>

		                    			</td>
		                    			<td>
		                    				<?php echo e($reward->description); ?>

		                    			</td>
		                    			<td>
		                    				<?php echo e($reward->created_at); ?>

		                    			</td>
		                    		</tr>
	                    		<?php else: ?>

	                    		<?php endif; ?>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        
	                    </tbody>
	                </table>
	            </div>
	            <?php echo e($rewards->links()); ?>

            </div>
		</div>
	</div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
	  		<div class="modal-header">
	    		<h5 class="modal-title" id="exampleModalLabel">Monto actual</h5>
			    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			    	<span aria-hidden="true">&times;</span>
			    </button>
			</div>

  			<div class="modal-body">
  				<div style="vertical-aling: middle">
                    <span class="float-left">
                    	<img src="<?php echo e(asset('icons/tokens.png')); ?>" id="coin" alt="">
                    </span>
                    <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 15px">
                      	<?php echo e($bank->amount); ?>

                    </div>
                </div>
			</div>
			
			<div class="modal-footer">
			    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	  		</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/reward/reward.blade.php ENDPATH**/ ?>