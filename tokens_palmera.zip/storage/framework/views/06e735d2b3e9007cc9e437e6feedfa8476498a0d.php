<?php $__env->startSection('title'); ?>
	<?php echo e(trans('global.users')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php
	use App\Department;
	$departments = Department::get();
?>

<?php $__env->startSection('content'); ?>
	<style>
		body
		{
			background-color: #00A6CE;
		}		
	</style>
	<div class="page-header" >
    	<div class="container text-center">
        	<div class="card card col-md-5 f-p-m" style="display: inline-block" >
    			<form class="form" id="form-pago" method="POST" action="<?php echo e(route('user.store')); ?>">
		        	<div class="card-header card-header-primary text-center h">
		            	<h3 class="display-4 text-uppercase"><?php echo e(trans('global.registerUser')); ?></h3>
		        	</div>
        			<div class="card-body">
						            
	            		<div class="input-group">
		                	<div class="input-group-prepend">
		                    	<span class="input-group-text">
		                        	<i class="material-icons">person</i>
		                    	</span>
		                	</div>
	                		<input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(trans('global.name')); ?>" style="" required="on">
	            		</div>
			            <div class="input-group">
			                <div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">person</i>
			                    </span>
			                </div>
			                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="<?php echo e(trans('global.lastName')); ?>" style="margin-left: 0px;" required="on">
			            </div>
			            <div class="input-group">
			                <div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">mail</i>
			                    </span>
			                </div>
			                <input type="text" name="email" id="email" class="form-control" placeholder="<?php echo e(trans('global.email')); ?>" value="" required="on" autocomplete="off" data-toggle="tooltip" data-html="true" data-placement="right" title="<?php echo e(trans('global.emailRegister')); ?>">
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">group</i>
			                    </span>
			                </div>
			                <select class="form-control" name="type">
			                	<option value="1" selected disabled>
			                		<?php echo e(trans('global.user')); ?>/<?php echo e(trans('global.admin')); ?>

			                	</option>

			                	<option value="1" id="user"> 
			                		Usuario
			                	</option>

			                	<option value="2" id="admin">
			                		Administrador
			                	</option>
			                	
			                </select>
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">group_work</i>
			                    </span>
			                </div>
			                <select class="form-control" name="department">
			                	<option selected disabled>
			                		<?php echo e(trans('global.department')); ?>

			                	</option>
			                	<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                		<option value="<?php echo e($department->id); ?>">
			                			<?php echo e($department->name); ?>

			                		</option>

			                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                	
			                </select>
			            </div>
			            <div class="input-group">
			            	<div class="input-group-prepend">
			                    <span class="input-group-text">
			                        <i class="material-icons">vpn_key</i>
			                    </span>
			                </div>
			                <input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(trans('global.password')); ?>" value="" required="on" autocomplete="off">
			            </div>
			            <div class=" text-center">
			                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="registrar" value="<?php echo e(trans('global.registerUser')); ?>"></input>
			            </div>
		        	</div>
    			</form>
			</div>
    	</div>
	</div>
	<div class="main main-raised">
    	<div class="section section-basic" style="padding: 10px 0px">
        	<div class="container">
            	<div id="">
                	<div class="title text-center text-uppercase">
                    	<h2><?php echo e(trans('global.users')); ?></h2>
                	</div>
            	</div>

            	<div class="table-responsive">
	            	<table class="table table-striped text-center" width="100%">
	                	<thead class="text-uppercase">
	                    	<tr>
	                        	<th><?php echo e(trans('global.name')); ?></th> <th><?php echo e(trans('global.lastName')); ?></th> <th><?php echo e(trans('global.email')); ?></th> <th><?php echo e(trans('global.edit')); ?></th> <th><?php echo e(trans('global.delete')); ?></th>
	                    	</tr>
	                	</thead>

	                	<tbody>
	                		<?php if($users->count()): ?>  
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
									<tr>
										<td><?php echo e($user->name); ?></td>
										<td><?php echo e($user->last_name); ?></td>
										<td><?php echo e($user->email); ?></td>
										<td>
											<button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#exampleModal-<?php echo e($user->id); ?>">
										  		<span class="glyphicon glyphicon-pencil">
													<i class="material-icons">edit</i>
												</span>
											</button>
											<div class="modal fade" id="exampleModal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  	<div class="modal-dialog" role="document">
											    	<div class="modal-content">
											      		<div class="modal-body">
											      			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          													<span aria-hidden="true">&times;</span>
	        												</button>
											      			
											        		<form class="form" id="form-pago" method="POST" action="<?php echo e(route('user.update', $user->id)); ?>" role="form">
												    			<?php echo e(csrf_field()); ?>

												    			<input name="_method" type="hidden" value="PATCH">
														        <div class="card-header card-header-primary text-center h">
														            <h3 class="card-title text-center inline">Editar</h3>
														        </div>

												        		<div class="card-body">
												            
													            	<div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">person</i>
														                    </span>
														                </div>
													                	<input type="text" name="name" id="name" class="form-control" placeholder="Nombre" style="" required="on" value="<?php echo e($user->name); ?>">
													            	</div>

														            <div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">person</i>
														                    </span>
														                </div>
														                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Apellido" style="margin-left: 0px;" required="on" value="<?php echo e($user->last_name); ?>">
														            </div>
												            
														            <div class="input-group">
														                <div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">mail</i>
														                    </span>
														                </div>
														                <input type="email" name="email" id="email" class="form-control" placeholder="Example@palmera.marketing" required="on" value="<?php echo e($user->email); ?>">
														            </div>

														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">group</i>
														                    </span>
														                </div>
														                <select class="form-control" >
														                	<option value="user" selected disabled>
														                		Usuario/Administrador
														                	</option>

														                	<option value="user" id="user"> 
														                		Usuario
														                	</option>

														                	<option value="admin" id="admin">
														                		Administrador
														                	</option>
														                	
														                </select>
														            </div>

														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">group_work</i>
														                    </span>
														                </div>
														                <select class="form-control" value="">
														                	<option value="user" selected disabled>
														                		Equipo
														                	</option>
																			<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<option value="<?php echo e($department->id); ?>">
																					<?php echo e($department->name); ?>

																				</option>
																			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														                </select>
														            </div>
														            <div class="input-group">
														            	<div class="input-group-prepend">
														                    <span class="input-group-text">
														                        <i class="material-icons">vpn_key</i>
														                    </span>
														                </div>
														                <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña" value="" required="on" value="<?php echo e($user->password); ?>">
														            </div>
														            <div class=" text-center">
														                <input type="submit" class="btn btn-default btn-link btn-wd btn-lg" name="actualizar" value="actualizar"></input>
														            </div>
														        </div>
												    		</form>
											      		</div>
											    	</div>
											  	</div>
											</div>
										</td>
										<td>
											<button type="button" class="btn btn-danger  btn-sm" data-toggle="modal" data-target="#exampleModal2-<?php echo e($user->id); ?>">
											 	<span class="glyphicon glyphicon-trash">
													<i class="material-icons">delete</i>
												</span>
											</button>
											<div class="modal fade" id="exampleModal2-<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  	<div class="modal-dialog" role="document">
											    	<div class="modal-content">
												      	<div class="modal-body">
												      		<div class="card-header card-header-primary text-center h">
										        				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										          					<span aria-hidden="true">&times;</span>
										        				</button>
												            	<h3 class="card-title text-center inline">Eliminar</h3>
												        	</div>
												      		<p>¿Realmente desea eliminar a <?php echo e($user->name." ".$user->last_name); ?>?</p>
												      	</div>
											      		<div class="modal-footer text-center">
											        		<form class="form-inline text-center mr-auto ml-auto" action="<?php echo e(action('UserController@destroy', $user->id)); ?>" method="post">
																<?php echo e(csrf_field()); ?>

																<input name="_method" type="hidden" value="DELETE">
																<button class="btn btn-danger btn-link btn-wd btn-lg" type="submit">
																	Eliminar
																</button>
															</form>
											      		</div>
											    	</div>
											  	</div>
											</div>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
							<?php else: ?>
								<tr>
									<td colspan="8"></td>
								</tr>
	             			<?php endif; ?>
	                	</tbody>
	            	</table>
            	</div>
            	<?php echo e($users->links()); ?>

        	</div>
    	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<style type="text/css" media="screen">
		.modal-backdrop	{
			z-index: -3;
		}		
	</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/users/users.blade.php ENDPATH**/ ?>