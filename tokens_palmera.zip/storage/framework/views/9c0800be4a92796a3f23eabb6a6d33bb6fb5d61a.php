<!DOCTYPE html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
            <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <link rel="icon" type="image/ico" href="<?php echo e(asset('favicon.ico')); ?>">
            <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons">
            <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
            
            
            <link href="<?php echo e(asset('assets/css/material-kit.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(asset('assets/css/rotating-card.css')); ?>" rel="stylesheet">
            <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animations.css')); ?>">
            <style type="text/css" media="screen">
                body, .other-bg
                {
                    background-color: ;
                }
                .force-scroll
                {
                    overflow-y: scroll;
                    height: 500px;
                    overflow-x: scroll;
                    width: 400px;
                }
                .contenedor
                {
                    margin: 2rem auto;
                    border: 1px solid #fff;
                    height: 300px;
                    width:90%;
                    max-width: 400px;
                    background: #fff;
                    overflow:auto;
                    box-sizing: border-box;
                    padding:0 1rem;
                }
                .contenedor::-webkit-scrollbar
                {
                    -webkit-appearance: none;
                }
                .contenedor::-webkit-scrollbar:vertical
                {
                    width:10px;
                }
                .contenedor::-webkit-scrollbar-button:increment,.contenedor::-webkit-scrollbar-button
                {
                    display: none;
                } 
                .contenedor::-webkit-scrollbar:horizontal
                {
                    height: 10px;
                }
                .contenedor::-webkit-scrollbar-thumb
                {
                    background-color: #fff;
                    border-radius: 20px;
                    border: 2px solid #fff;
                }
                .contenedor::-webkit-scrollbar-track
                {
                    border-radius: 10px;  
                }
            </style>
            <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font.css')); ?>">
            <?php echo $__env->yieldContent('sytlesheet'); ?>
            <title>TOKENS - <?php echo $__env->yieldContent('title'); ?></title>
        </head>
        <body>
            
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible fade show col-md-3" role="alert" style="position: fixed; bottom: 10px; z-index: 15; right: 15px; width: 50%;">
                    <strong>Error!</strong> Revise los campos obligatorios.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                        <br>
                        <br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show col-md-3" role="alert" style="position: fixed; bottom: 10px; z-index: 15; right: 15px; width: 50%;">
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
                <div class="alert alert-danger alert-dismissible fade show col-md-3" role="alert" style="position: fixed; bottom: 10px; z-index: 15; right: 15px; width: 50%;">
                    <?php echo e(Session::get('danger')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('navbar'); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('assets/js/core/bootstrap-material-design.min.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('assets/js/plugins/moment.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/plugins/bootstrap-datetimepicker.js')); ?>" type="text/javascript"></script>
            <script src="<?php echo e(asset('assets/js/plugins/nouislider.min.js')); ?>" type="text/javascript"></script>
            <script async defer src="https://buttons.github.io/buttons.js"></script>
            <script src="<?php echo e(asset('assets/js/material-kit.js')); ?>" type="text/javascript"></script>
            <script type="text/javascript">
                $().ready(function()
                {
                    $('[rel="tooltip"]').tooltip();
                    $('a.scroll-down').click(function(e)
                    {
                        e.preventDefault();
                        scroll_target = $(this).data('href');
                         $('html, body').animate(
                         {
                             scrollTop: $(scroll_target).offset().top - 60
                         }, 1000);
                    });

                });
                function rotateCard(btn)
                {
                    var $card = $(btn).closest('.card-container');
                    console.log($card);
                    if($card.hasClass('hover'))
                    {
                        $card.removeClass('hover');
                    }
                    else
                    {
                        $card.addClass('hover');
                    }
                }
            </script>
            <?php echo $__env->yieldContent('script'); ?>
        </body>
    </html><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/layouts/app.blade.php ENDPATH**/ ?>