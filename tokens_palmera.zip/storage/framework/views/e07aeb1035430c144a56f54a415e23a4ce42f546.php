<?php $__env->startSection('title'); ?>
	<?php echo e(trans('global.products')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<style>
		body
		{
			background-color: #79E2DB;
		}		
	</style>

<div class="page-header">
    <div class="container text-center">
        <div class="card card col-md-5 f-p-m" style="display: inline-block" >
    		<form class="form" id="form-pago" method="POST" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="display-4 text-uppercase"><?php echo e(trans('global.registerUser')); ?></h3>
		        </div>

        		<div class="card-body">
	            	<div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">add_shopping_cart</i>
		                    </span>
		                </div>
	                	<input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(trans('global.products')); ?>" style="" required="on">
	            	</div>

	            	<div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">edit</i>
		                    </span>
		                </div>
		                <textarea name="description" id="description" cols="20" rows="2" class="form-control" maxlength="" placeholder="<?php echo e(trans('global.description')); ?>"></textarea>
		            </div>
		            <div class="input-group">
		            	<div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">person</i>
		                    </span>
		                </div>
		                <select class="form-control" name="admin" >
		                	<option selected disabled>
		                		<?php echo e(trans('global.responsable')); ?>

		                	</option>
		                	<?php 
		                		use App\User;
		                		$users = User::get();
		                	?>
		                	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<?php if( $user->type != 1): ?>
			                		<option value="<?php echo e($user->id); ?>">
			                			<?php echo e($user->name." ".$user->last_name); ?>

			                		</option>
			                	<?php else: ?>
			                	<?php endif; ?>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </select>
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
			                	<img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="" alt="" width="24">
			                </span>
		                </div>
		                <input type="number" name="price" id="price" class="form-control" placeholder="<?php echo e(trans('global.price')); ?>" style="margin-left: 0px;" required="on">
		            </div>
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">insert_photo</i>
		                    </span>
		                </div>
		                <span class="file-upload">
		                	<input type="file" id="file-upload" onchange="cambiar()" accept="image/*" name="img" id="img" class="form-control" placeholder="Precio" style="display:none;" required>
		                </span>
		                <input type="text" name="" id="info" class="form-control" disabled style="background-color: #fff;">
		                <label for="file-upload" class="subir btn btn-primary btn-fab btn-round">
		               		<i class="material-icons">attach_file</i>							
		                </label>
		            </div>
		            <div class=" text-center">
		                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="registrar" value="<?php echo e(trans('global.registerUser')); ?>"></input>
		            </div>
		        </div>
    		</form>
		</div>
    </div>
</div>               
<div class="main main-raised">
    <div class="section section-basic" style="padding: 10px 0px">
        <div class="container">
            <div id="">
                <div class="title text-center text-uppercase">
                    <h2><?php echo e(trans('global.products')); ?></h2>
                </div>
            </div>
            <div class="table-responsive">
            <table class="table responsive-table centered text-center" id="historial_operaciones" width="100%" >
                <thead class="text-uppercase">
                    <tr>
                        <th id="lok" value="lokj"><?php echo e(trans('global.name')); ?></th> <th><?php echo e(trans('global.description')); ?></th> <th><?php echo e(trans('global.responsable')); ?></th> <th><?php echo e(trans('global.price')); ?></th>  <th><?php echo e(trans('global.edit')); ?></th> <th><?php echo e(trans('global.delete')); ?></th>
                    </tr>
                </thead>
                <tbody>
                	<?php if($products->count()): ?>  
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
							<tr>
								<td><?php echo e($product->name); ?></td>
								<td><?php echo e($product->description); ?></td>
								<td><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($user->id == $product->admin): ?>
											<?php echo e($user->name." ".$user->last_name); ?>

										<?php else: ?>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
								<td><?php echo e($product->price); ?></td>
								<td>
									<button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#exampleModal-<?php echo e($product->id); ?>">
								  		<span class="glyphicon glyphicon-pencil">
											<i class="material-icons">edit</i>
										</span>
									</button>
									<div class="modal fade" id="exampleModal-<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  	<div class="modal-dialog" role="document">
									    	<div class="modal-content">
									    		<div class="modal-header">
									    			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
      													<span aria-hidden="true">&times;</span>
    												</button>
									    		</div>
									      		<div class="modal-body" style="z-index: 40;">
									      			
    												
									      			
									        		<form class="form" id="form-pago" method="POST" action="<?php echo e(route('product.update', $product->id)); ?>" role="form" enctype="multipart/form-data">
										    			<?php echo e(csrf_field()); ?>

										    			<input name="_method" type="hidden" value="PATCH">
										    			<div class="card-header card-header-primary text-center" style="vertical-align: middle; ">
												        	<div style="width: 250px; height: 250px; background-image: url('<?php echo e(asset('uploads/'.$product->img)); ?>'); background-position: center; background-repeat: no-repeat; background-size: cover; border-radius: 0%; display: inline-block; vertical-align: middle; margin: 0 auto;"></div>
												            
												        </div>
												        

										        		<div class="card-body py-3">
										            
											            	<div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">add_shopping_cart</i>
												                    </span>
												                </div>
											                	<input type="text" name="name" id="name" class="form-control" placeholder="Producto" style="" required="on" value="<?php echo e($product->name); ?>">
											            	</div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">edit</i>
												                    </span>
												                </div>
												                <textarea name="description" id="description" cols="20" rows="2" class="form-control" maxlength="" placeholder="Descripción" value="<?php echo e($product->description); ?>"><?php echo e($product->description); ?></textarea>
												            </div>
												            <div class="input-group">
												            	<div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">person</i>
												                    </span>
												                </div>
												                <select class="form-control" name="admin" >
												                	<option disabled>
												                		Supervisor
												                	</option>
												                	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												                		<?php if( $user->type != 1): ?>
												                			<?php if($user->id == $product->admin): ?>
												                				<option selected value="<?php echo e($user->id); ?>">
														                			<?php echo e($user->name." ".$user->last_name); ?>

														                		</option>
												                			<?php else: ?>
																				<option value="<?php echo e($user->id); ?>">
														                			<?php echo e($user->name." ".$user->last_name); ?>

														                		</option>
												                			<?php endif; ?>
													                		
													                	<?php else: ?>
													                	<?php endif; ?>
												                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												                </select>
												            </div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                        <i class="material-icons">euro</i>
												                    </span>
												                </div>
												                <input type="number" name="price" id="price" class="form-control" placeholder="Precio" style="margin-left: 0px;" required="on" value="<?php echo e($product->price); ?>">
												            </div>
												            <div class="input-group">
												                <div class="input-group-prepend">
												                    <span class="input-group-text">
												                    	
												                        <i class="material-icons">insert_photo</i>
												                    </span>
												                </div>
												                <span class="file-upload">
												                	<input type="file" id="file-upload-<?php echo e($product->id); ?>" onchange="cambiar_<?php echo e($product->id); ?>()" accept="image/*" name="img" id="img" class="form-control" placeholder="Precio" style="display:none;">
												                </span>
												                <input type="text" name="" id="info-<?php echo e($product->id); ?>" class="form-control" disabled style="background-color: #fff;" value="">
												                <label for="file-upload-<?php echo e($product->id); ?>" class="subir btn btn-primary btn-fab btn-round" value="">
												               		<i class="material-icons">attach_file</i>							
												                </label>
												                <script type="application/javascript">
																	function cambiar_<?php echo e($product->id); ?>(){
															    		var pdrs = document.getElementById('file-upload-<?php echo e($product->id); ?>').files[0].name;
															   			document.getElementById('info-<?php echo e($product->id); ?>').value = pdrs;
																	}
																</script>
												            </div>
												            <div class=" text-center">
												                <input type="submit" class="btn btn-default btn-link btn-wd btn-lg" name="actualizar" value="actualizar">
												            </div>
												        </div>
										    		</form>
									      		</div>
									    	</div>
									  	</div>
									</div>
									</td>
								<td>
									<form action="<?php echo e(action('ProductsController@destroy', $product->id)); ?>" method="post">
										<?php echo e(csrf_field()); ?>

										<input name="_method" type="hidden" value="DELETE">
										<button class="btn btn-danger btn-sm" type="submit">
											<span class="glyphicon glyphicon-trash">
												<i class="material-icons">delete</i>
											</span>
										</button>
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php else: ?>
							<tr>
								<td colspan="8"></td>
							</tr>
             		 <?php endif; ?>
                </tbody>
            </table>
        </div>
        <span><?php echo e($products->links()); ?></span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="application/javascript">
		function cambiar(){
    		var pdrs = document.getElementById('file-upload').files[0].name;
   			document.getElementById('info').value = pdrs;
		}
	</script>
	<style type="text/css" media="screen">
		.modal-backdrop	{
			z-index: -3;
		}		
	</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/products/products.blade.php ENDPATH**/ ?>