<?php $__env->startSection('title'); ?>
	<?php echo e(trans('global.password')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php
	use Illuminate\Support\Facades\Crypt;
?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<style>
		body
		{
			background-color: #00A6CE;
		}		
	</style>
<div class="page-header">
    <div class="container text-center">
        <div class="card car-login card col-md-5" style="display: inline-block" >
        	<?php
        		$id = Auth::user()->id;
        	?>
    		<form class="form" id="" method="POST" action="<?php echo e(route('CP', $id)); ?>" role="form">
    			<?php echo e(csrf_field()); ?>

    			
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="display-4 text-uppercase"><?php echo e(trans('global.passwordCh')); ?></h3>
		        </div>
        		<div class="card-body py-3">
        			
	            	<div class="input-group py-3">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">vpn_key</i>
		                    </span>
		                </div>
	                	<input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(trans('global.passwordN')); ?>" style="" required="on">
	                	<button type="button" class="btn btn-sm btn-link" onclick=" cambiar();"><i class="material-icons">remove_red_eye</i></button>
	            	</div>
	            	<div class="input-group py-3">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">vpn_key</i>
		                    </span>
		                </div>
	                	<input type="password" name="passwordConfirm" id="passwordConfirm" class="form-control" placeholder="<?php echo e(trans('global.passwordC')); ?>" style="" required="on">
	                	<button type="button" class="btn btn-sm btn-link" onclick=" cambiar2();"><i class="material-icons">remove_red_eye</i></button>
	            	</div>
		            <div class="text-center">
		                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" id="changePasswordButton" name="registrar" value="<?php echo e(trans('global.change')); ?>" disabled>
		            </div>
		        </div>
    		</form>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="application/javascript">
		function cambiar()
		{
    		var password = document.getElementById('password');
     		if (password.type == 'password')
    		{
    			password.type = 'text';
    		}
    		else
    		{
    			password.type = 'password';
    		}
		}
		function cambiar2()
		{
    		var passwordConfirm = document.getElementById('passwordConfirm');
    		if (passwordConfirm.type == 'password')
    		{
    			passwordConfirm.type = 'text';
    		}
    		else
    		{
    			passwordConfirm.type = 'password';
    		}
		}
		function confirmPassword()
		{
			var passwordO = document.getElementById('password');
			var passwordC = document.getElementById('passwordConfirm');
			var passwordConfirm = document.getElementById('changePasswordButton');

			if (passwordO.value == passwordC.value && passwordO.value.length >= 8)
			{
				passwordConfirm.removeAttribute('disabled');
			}
			else
			{
				passwordConfirm.setAttribute('disabled', 'on');
			}
		}
		setInterval("confirmPassword()", 5);
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/users/changePassword.blade.php ENDPATH**/ ?>