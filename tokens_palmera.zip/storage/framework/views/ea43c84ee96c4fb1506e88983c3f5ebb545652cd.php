<?php
    use App\Wallet;
    // use Session;
    use App\Product;
    use App\Bank;
    $bank = Bank::where('id', 1)->first();
    $wallet = Wallet::where('id_user', Auth::user()->id)->value('amount');
?>
<nav class="navbar navbar-transparent navbar-color-on-scroll fixed-top navbar-expand-lg" color-on-scroll="75" id="sectionsNav">
    <div class="container">
        <div class="navbar-translate">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                TOKENS PALM ERA
            </a>
            
            <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" aria-disabled="true" >
                        <span class="" style="vertical-align: middle;">
                            <img src="<?php echo e(asset('icons/tokens.png')); ?>" id="coin" alt="" style="width: 19px; height: 19px; margin: -4px 6px 0px 0px;">
                            <span class="h5 font-weight-light" style="font-size: 14px;">
                                <?php echo e($wallet); ?>

                            </span>
                        </span>
                    </a>
                </li>
            <?php if(Auth::user()->type != 1): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                            <i class="material-icons">
                                person_add
                            </i>
                            <?php echo e(trans('global.users')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('products')); ?>">
                            <i class="material-icons">
                                add_shopping_cart
                            </i>
                            <?php echo e(trans('global.products')); ?>

                        </a>
                    </li>
                <?php endif; ?>
                <li class="dropdown nav-item">
                    <a href="#" class="nav-link" data-toggle="dropdown">
                        <i class="material-icons">
                            notifications
                        </i>
                        <span>
                            <?php if(count(Auth::user()->unreadNotifications) <= 0): ?>
                                <sup style="display: none"><?php echo e(count(Auth::user()->unreadNotifications)); ?></sup>
                            <?php elseif(count(Auth::user()->unreadNotifications) > 0 && count(Auth::user()->unreadNotifications) <=  9): ?>
                            <div class="bg-danger text-center" style="width: 14px; height: 14px; border-radius: 100%; display:inline-block; margin-left: -10px; padding-top: 3.5px;">
                                <sup style="font-size: 9px;color: #fff; vertical-align: middle; top: -7px;"><?php echo e(count(Auth::user()->unreadNotifications)); ?></sup>
                            </div>
                            <?php elseif(count(Auth::user()->unreadNotifications) > 9): ?>
                            <div class="bg-danger text-center" style="width: 14px; height: 14px; border-radius: 100%; display:inline-block; margin-left: -10px; padding-top: 3.5px;">
                                <sup style="font-size: 9px;color: #fff; vertical-align: middle; top: -7px;">+9</sup>
                            </div>
                            <?php endif; ?>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-with-icons force-scroll contenedor text-center" onclick="return getNotification()" style="min-width: 300px; max-height: 600px; margin-top: 0px;">
                        <a href="<?php echo e(route('maskAsRead')); ?>" class="dropdown-item text-center" style="margin: 0px; padding: 12px; display: inline-block; width: 112px;">
                            <i class="material-icons text-default">
                                visibility
                            </i>
                            
                        </a>
                        <a href="<?php echo e(route('deleteNotifications')); ?>" class="dropdown-item text-center" style="margin: 0px; padding: 12px; display: inline-block; width: 112px;">
                            <i class="material-icons text-danger">
                                delete_forever
                            </i>
                            
                        </a>
                        <?php
                            use App\User;
                            $users = User::get();
                            $walletsC = Wallet::get();
                            $productsC = Product::get()
                        ?>
                        <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($notification->data['type'] == "product_added"): ?>
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="Nuevo premio" style="margin: 0px;">
                                    <i class="material-icons">
                                        add_shopping_cart
                                    </i>
                                    <span>
                                        <?php echo e($notification->data['product']); ?>

                                    </span>
                                </a>
                            <?php elseif($notification->data['type'] == "request"): ?>
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="Quiere adquirir <?php echo e($notification->data['product_name']); ?>" style="margin: 0px;">
                                    <i class="material-icons">
                                        style
                                    </i>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->id == $notification->data['user']): ?>
                                            <?php echo e($user->name); ?>

                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                        <form action="<?php echo e(route('purchaseAccepted')); ?>" method="post" accept-charset="utf-8" class="form-inline" style="position: absolute; right: 26.5px; bottom: 12px;">
                                            <input type="hidden" name="notification" value="<?php echo e($notification->id); ?>">
                                            <input type="hidden" name="user" value="<?php echo e($notification->data['user']); ?>">
                                            <input type="hidden" name="product" value="<?php echo e($notification->data['product_id']); ?>">
                                            <input type="hidden" name="admin" value="<?php echo e($notification->data['admin']); ?>">
                                            <?php
                                                $product = Product::where('id', $notification->data['product_id'])->first();
                                            ?>
                                            <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                            <input type="hidden" name="wallet" value="<?php echo e($wallet); ?>">
                                            <input type="hidden" name="bank" value="<?php echo e($bank->amount); ?>">
                                            <input type="hidden" name="" value="">
                                            <?php $__currentLoopData = $walletsC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $walletC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($walletC->id_user ==  $notification->data['user']): ?>
                                                    <?php $__currentLoopData = $productsC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($productC->id == $notification->data['product_id']): ?>
                                                            <?php if($walletC->amount >= $productC->price): ?>
                                                                <button type="submit" class="btn btn-info btn-sm" style="margin: 0 2.5px 0 0; padding: 0; width: 25px; height: 25px;" style="vertical-align: middle;">
                                                                    <i class="material-icons" style="margin: 0;">
                                                                        done
                                                                    </i>
                                                                </button>
                                                            <?php else: ?>
                                                                <button type="submit" class="btn btn-default btn-sm" disabled style="margin: 0 2.5px 0 0; padding: 0; width: 25px; height: 25px;" style="vertical-align: middle;">
                                                                    <i class="material-icons" style="margin: 0;">
                                                                        done
                                                                    </i>
                                                                </button>

                                                            <?php endif; ?>
                                                        <?php else: ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </form>
                                    <i>
                                        <form action="<?php echo e(route('purchaseRejected')); ?>" method="post" accept-charset="utf-8" class="form-inline" style="position: absolute; right: 0; bottom: 12px;">
                                            <input type="hidden" name="user" value="<?php echo e($notification->data['user']); ?>">
                                            <input type="hidden" name="notification"  value="<?php echo e($notification->id); ?>">        
                                            <button type="submit" class="btn btn-danger btn-sm" style="margin: 0 0 0 2.5px; padding: 0; width: 25px; height: 25px;">
                                                <i class="material-icons" style="margin: 0;">
                                                    clear
                                                </i>
                                            </button>
                                        </form>
                                    </i> 
                                </a>
                            <?php elseif($notification->data['type'] == "rejected"): ?>
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="" style="margin: 0px;">
                                    <i class="material-icons">
                                        clear
                                    </i>
                                    <span>
                                        Solicitud rechazada
                                    </span>
                                </a>
                            <?php elseif($notification->data['type'] == "accepted"): ?>
                                <a href="#" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="" style="margin: 0px">
                                    <i class="material-icons">
                                        sentiment_satisfied_alt
                                    </i>
                                    <span>
                                        Compra exitosa
                                    </span>
                                </a>
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </li>
                <li class="nav-item">
                    <?php
                        $_lang = session()->get('lang');
                    ?>
                    <?php if($_lang == 'en'): ?>
                        <a href="<?php echo e(route('change_lang', ['lang' => 'es'])); ?>" class="nav-link">
                            <img src="<?php echo e(asset('icons/en.svg')); ?>" width="30px" style="">
                        </a>
                    <?php elseif($_lang == 'es'): ?>
                        <a href="<?php echo e(route('change_lang', ['lang' => 'en'])); ?>" class="nav-link">
                            <img src="<?php echo e(asset('icons/es.svg')); ?>" width="30px" style="">
                        </a>
                    <?php else: ?>

                    <?php endif; ?>
                </li>
                
                <li class="dropdown nav-item">
                    <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                        <i class="material-icons">
                            account_circle
                        </i>
                        <?php echo e(Auth::user()->name); ?> 
                    </a>                    
                    <div class="dropdown-menu dropdown-with-icons">
                        
                        <?php if(Auth::user()->type == 3): ?>
                            <a href="<?php echo e(route('bank')); ?>" class="dropdown-item">
                                <i class="material-icons">
                                    account_balance
                                </i>
                                <?php echo e(trans('global.bank')); ?>

                            </a>
                        <?php endif; ?>
                        <?php if(Auth::user()->type != 1): ?>
                            <a href="<?php echo e(route('reward')); ?>" class="dropdown-item">
                                <i class="material-icons">
                                    redeem
                                </i>
                                <?php echo e(trans('global.reward')); ?>

                            </a>
                        <?php endif; ?>
                        
                        <a href="<?php echo e(route('changePassword')); ?>" class="dropdown-item">
                            <i class="material-icons">vpn_key</i>
                            <?php echo e(trans('global.password')); ?>

                        </a>
                        
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="material-icons">
                                input
                            </i>
                            <?php echo e(trans('global.logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>