	<?php $__env->startSection('title'); ?>
		<?php echo e(trans('global.home')); ?>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('stylesheet'); ?>
	<?php $__env->stopSection(); ?>
	
	<?php $__env->startSection('navbar'); ?>
    	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php $__env->stopSection(); ?>

	<?php
	    use App\Wallet;
	    $wallet = Wallet::where('id_user', Auth::user()->id)->value('amount');
	?>

	<?php $__env->startSection('stylesheet'); ?>
		
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('content'); ?>
		<style>
		    body
            {
                background: rgba(165,105,189,1);
            }
		</style>  
		   
	    	<?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    
		    <div class="text-center py-5" style="padding: 0px;">
				<?php if($products->count()): ?>  
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card-container manual-flip" style="width: 275px; display: inline-block; margin: 20px;">
							<div class="card" style="width: 275px; display: inline-block; margin: 10px">
								<div class="front">
									<div class="card-img-top" style="width: 275px; height: 232px; background-image: url('<?php echo e(asset('uploads/'.$product->img)); ?>'); background-position: center; background-repeat: no-repeat; background-size: cover;">
									</div>
									
									
									<div class="card-body">
										<h4 class="card-text h4"><?php echo e($product->name); ?></h4>
										<p class="card-text" style="vertical-align: middle;">
						                    <img src="<?php echo e(asset('icons/tokens.svg')); ?>" width="21px" style="margin: -10px 5px 0px 0px;">
						                    <span class="h4"><?php echo e($product->price); ?></span>
									    </p>
									</div>
									<div class="card-footer" style="position: absolute; bottom: 0px; left: 20%;">
									 	<button class="btn btn-primary mr-auto ml-auto" onclick="rotateCard(this)">
										 	<?php echo e(trans('global.more')); ?>

										</button>
									</div>
								</div>
								
								<div class="back">
									<div class="card-body" style="vertical-align: middle;">
										<button type="button" class="close" onclick="rotateCard(this)">
					      					<span aria-hidden="true">&times;</span>
					    				</button>
										<h4 class="card-text h3"><?php echo e($product->name); ?></h4>
										
										<p class="card-text" style="vertical-align: middle;">
						                    <img src="<?php echo e(asset('icons/tokens.svg')); ?>" width="21px" style="margin: -10px 5px 0px 0px;" id="coin">
						                    <span class="h3"><?php echo e($product->price); ?></span>
									    </p>
										<p class="card-text py-5">
											<?php echo e($product->description); ?>

										</p>
									</div>
									<div class="card-footer" style="position: absolute; bottom: 0px;;">
										<form action="<?php echo e(route('purchaseRequest')); ?>" method="post" accept-charset="utf-8">
									    	<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
									    	<input type="hidden" name="product_name" value="<?php echo e($product->name); ?>">
						  					<input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
						  					<input type="hidden" name="admin" value="<?php echo e($product->admin); ?>">
						  					<?php if($product->price > $wallet): ?>
												<button type="submit" class="btn btn-primary ml-auto mr-auto" name="purchase" value="<?php echo e(trans('global.purchase')); ?>" disabled><?php echo e(trans('global.purchase')); ?></button>
											<?php else: ?>
												<button type="submit" class="btn btn-primary ml-auto mr-auto" name="purchase" value="<?php echo e(trans('global.purchase')); ?>"><?php echo e(trans('global.purchase')); ?></button>
											<?php endif; ?>	
									    </form>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				<?php else: ?>
		 		<?php endif; ?>
		    </div>
		    <div class="py-3">
		    	<?php echo e($products->links()); ?>

		    </div>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/home/home.blade.php ENDPATH**/ ?>