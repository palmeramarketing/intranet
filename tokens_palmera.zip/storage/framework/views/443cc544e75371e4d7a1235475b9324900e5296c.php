<?php $__env->startSection('title'); ?>
	<?php echo e(trans('titles.users')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
	<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="container text-center">
        <div class="card card col-md-5 f-p-m" style="display: inline-block" >
    		<form class="form" id="form-pago" method="POST" action="<?php echo e(route('user.update', $user->id)); ?>" role="form">
    			<?php echo e(csrf_field()); ?>

    			<input name="_method" type="hidden" value="PATCH">
		        <div class="card-header card-header-primary text-center h">
		            <h3 class="card-title text-center inline">Registro</h3>
		        </div>

        		<div class="card-body">
            
	            	<div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">perm_identity</i>
		                    </span>
		                </div>
	                	<input type="text" name="name" id="name" class="form-control" placeholder="Nombre" style="" required="on" value="<?php echo e($user->name); ?>">
	            	</div>

		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">perm_identity</i>
		                    </span>
		                </div>
		                <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Apellido" style="margin-left: 0px;" required="on" value="<?php echo e($user->last_name); ?>">
		            </div>
            
		            <div class="input-group">
		                <div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">mail</i>
		                    </span>
		                </div>
		                <input type="email" name="email" id="email" class="form-control" placeholder="Example@palmera.marketing" required="on" value="<?php echo e($user->email); ?>">
		            </div>

		            <div class="input-group">
		            	<div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">group</i>
		                    </span>
		                </div>
		                <select class="form-control" >
		                	<option value="user" selected disabled>
		                		Usuario/Administrador
		                	</option>

		                	<option value="user" id="user"> 
		                		Usuario
		                	</option>

		                	<option value="admin" id="admin">
		                		Administrador
		                	</option>
		                	
		                </select>
		            </div>

		            <div class="input-group">
		            	<div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">group_work</i>
		                    </span>
		                </div>
		                <select class="form-control" >
		                	<option value="user" selected disabled>
		                		Departamento
		                	</option>

		                	<option value="it" id="it">
		                		IT
		                	</option>

		                	<option value="admin" id="it">
		                		CRM
		                	</option>
		                	
		                </select>
		            </div>

		            <div class="input-group">
		            	<div class="input-group-prepend">
		                    <span class="input-group-text">
		                        <i class="material-icons">lock_outline</i>
		                    </span>
		                </div>
		                <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña" value="" required="on" value="<?php echo e($user->password); ?>">
		            </div>

		            <div class=" text-center">
		                <input type="submit" class="btn btn-primary btn-link btn-wd btn-lg" name="actualizar" value="actualizar"></input>
		            </div>
		        </div>
    		</form>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/users/edit.blade.php ENDPATH**/ ?>