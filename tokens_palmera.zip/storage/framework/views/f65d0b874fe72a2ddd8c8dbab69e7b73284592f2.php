<?php $__env->startSection('title'); ?>
	<?php echo e(trans('global.bank')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php
    use App\Bank;
    use App\Wallet;
    use App\Department;
    use App\User;
    $users = User::get();
    $banks = Bank::get();
    $wallets = Wallet::get();
    $general_amount = 0;
    // $departments = Department::get();
?>

<?php $__env->startSection('content'); ?>
<style>
    body
    {
        background-color: #7FB2A5;
    }       
</style>
<div class="page-header">        
    <div class="container">
        <div class="card card col-md-5 mr-auto ml-auto" style="width: 320px; height: 145px; margin-top: 10px">
            <h3 class="text-center">MONTO ACTUAL</h3>
            <br>
            <div style="vertical-aling: middle">
                <span>
                	<img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="coin" alt="" width="30">
                </span>
                <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 0px; clear: both;">
                    <span style="float: right;" >
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($bank->name == 'Presidencia'): ?>
                                <?php echo e($bank->amount); ?>

                            <?php else: ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="card card col-md-5 mr-auto ml-auto" style="width: 320px; height: 145px; margin-top: 30px;">
            <h3 class="text-center">EN CIRCULACIÓN</h3>
            <br>
            <div style="vertical-aling: middle">           
                <span style="">
                    <img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="coin" alt="" width="30">
                </span>
                <div style="display: inline-block; float: right; vertical-aling: middle; font-size: 30px; margin-right: 15px">
                    <span style="float: right;">
                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $general_amount += $wallet->amount;
                            ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($general_amount.""); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
</div>


    <div class="text-center py-5" style="padding: 0px;">
        <?php if($departments->count()): ?>  
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($bank->name == $department->name): ?>
                        <div class="card-container manual-flip" style="width: 275px; display: inline-block; margin: 20px; height: 350px;">
                            <div class="card" style="width: 275px; display: inline-block; margin: 10px">
                                <div class="front" style="height: 350px;">
                                    
                                    
                                    
                                    <div class="card-body">
                                        <h4 class="card-text h3"><?php echo e($department->name); ?></h4>
                                        <p class="card-text" style="vertical-align: middle;">
                                            <img src="<?php echo e(asset('icons/tokens.svg')); ?>" width="21px" style="margin: -10px 5px 0px 0px;">
                                            <span class="h4"><?php echo e($bank->amount); ?></span>
                                        </p>
                                    </div>
                                    <div class="card-footer" style="position: absolute; bottom: 0px; left: 20%;">
                                        <button class="btn btn-primary mr-auto ml-auto" onclick="rotateCard(this)">
                                            <?php echo e(trans('global.more')); ?>

                                        </button>
                                    </div>
                                </div>
                                
                                <div class="back" style="height: 350px;">
                                    <div class="card-body" style="vertical-align: middle;">
                                        <button type="button" class="close" onclick="rotateCard(this)">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <h4 class="card-text h3"><?php echo e($department->name); ?></h4>
                                        
                                        <p class="card-text" style="vertical-align: middle;">
                                            <img src="<?php echo e(asset('icons/tokens.svg')); ?>" width="21px" style="margin: -10px 5px 0px 0px;" id="coin">
                                            <span class="h3"><?php echo e($bank->amount); ?></span>
                                        </p>
                                        <?php
                                        	$idBank = $bank->id;
                                        ?>

                                        <form action="<?php echo e(route('BankAndDepUpdate', $idBank)); ?>" class="form" role="form" method="POST">

                                        	<div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="" alt="" width="24">
                                                    </span>
                                                </div>
                                                <input type="tetx" name="name" class="form-control" value="<?php echo e($bank->name); ?>">
                                            </div>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="material-icons">person</i>
                                                    </span>
                                                </div>
                                                <select class="form-control" name="admin" >
                                                    <option disabled>
                                                        Supervisor
                                                    </option>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if( $user->type != 1): ?>
                                                            <?php if($user->id == $bank->id_admin): ?>
                                                                <option selected value="<?php echo e($user->id); ?>">
                                                                    <?php echo e($user->name." ".$user->last_name); ?>

                                                                </option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($user->id); ?>">
                                                                    <?php echo e($user->name." ".$user->last_name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                            
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <img src="<?php echo e(asset('icons/tokens.svg')); ?>" id="" alt="" width="24">
                                                    </span>
                                                </div>
                                                <input type="number" name="amount" class="form-control" value="<?php echo e($bank->amount); ?>">
                                            </div>
                                            <div class=" text-center" style="position: absolute; bottom: 10px; left: 25%;">
                                                <input type="submit" class="btn btn-default mr-auto ml-auto" name="actualizar" value="actualizar"></input>
                                            </div>
                                            
                                        </form>
                                    </div>
                                    <div class="card-footer" style="position: fixed; bottom: 10px;">
                                        <form action="<?php echo e(route('purchaseRequest')); ?>" method="post" accept-charset="utf-8">
                                            <input type="hidden" name="product_id" value="<?php echo e($department->id); ?>">
                                            <input type="hidden" name="product_name" value="<?php echo e($department->name); ?>">
                                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                            <input type="hidden" name="admin" value="<?php echo e($department->id_admin); ?>">
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <?php else: ?>
        <?php endif; ?>
    </div>
    <?php echo e($departments->links()); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokens_palmera\resources\views/bank/bank.blade.php ENDPATH**/ ?>